# Difficulty Model Documentation

## Overview

This exam question generator implements a **quantitative difficulty scoring system** to ensure fairness across different question versions. The system breaks down each question into measurable aspects and calculates a weighted difficulty score.

## Why This Matters

**The Problem:** Traditional randomized question generation can create unfair exams where some students get significantly harder questions than others, even though the questions look "similar" at first glance.

**The Solution:** Our difficulty model ensures that all question versions have equivalent complexity by:
1. Analyzing each transformation aspect independently
2. Assigning quantitative difficulty levels based on mathematical complexity
3. Balancing the overall difficulty across versions
4. Providing transparency through detailed breakdown metadata

---

## Difficulty Scoring Components

### 1. Rotation Difficulty (40% weight)

Rotation difficulty is based on the angle and axis complexity:

#### **Level 1: Easy Angles**
- **Angles:** 0°, 90°, 180°, 270°, 360°
- **Why Easy:** These angles have simple sine/cosine values (0, ±1)
- **Computation:** Minimal calculation required, often results in identity or simple matrices
- **Example:** Rotating 90° around X-axis

#### **Level 2: Moderate Angles**
- **Angles:** 30°, 45°, 60°, 120°, 135°, 150°, 210°, 225°, 240°, 300°, 315°, 330°
- **Why Moderate:** Common angles with known trigonometric values (√2/2, √3/2, 1/2)
- **Computation:** Requires trigonometric calculation but values are "nice"
- **Example:** Rotating 45° around Y-axis

#### **Level 3: Complex Angles**
- **Angles:** 22°, 37°, 73°, 107°, etc. (non-standard angles)
- **Why Hard:** Requires calculator for sine/cosine, decimal precision management
- **Computation:** More prone to rounding errors, harder to verify by hand
- **Example:** Rotating 37° around Z-axis

#### **Arbitrary Axis Bonus**
- Rotation around arbitrary axes (not X, Y, or Z) automatically gets Level 3
- Requires Rodrigues' rotation formula or quaternion mathematics

---

### 2. Translation Difficulty (30% weight)

Translation difficulty is based on the number of axes involved:

#### **Level 1: Single-Axis Translation**
- **Pattern:** Movement along only X, Y, or Z
- **Why Easy:** Only one component changes, straightforward addition
- **Matrix Impact:** Only one element in translation column is non-zero
- **Example:** Translate by (3, 0, 0)

#### **Level 2: Two-Axis Translation**
- **Pattern:** Movement in a plane (XY, XZ, or YZ)
- **Why Moderate:** Two vector components to track
- **Matrix Impact:** Two non-zero elements in translation column
- **Example:** Translate by (2, -1, 0)

#### **Level 3: Three-Axis Diagonal Translation**
- **Pattern:** Movement through 3D space with all components non-zero
- **Why Hard:** Full 3D vector addition, requires careful tracking of all coordinates
- **Matrix Impact:** All three translation elements are non-zero
- **Example:** Translate by (2, -1, 3)

#### **Decimal Complexity Modifier**
- Non-integer values increase difficulty by one level (capped at 3)
- Example: (2.73, -1.42, 0) is harder than (3, -1, 0)

---

### 3. Scaling Difficulty (30% weight)

Scaling difficulty depends on uniformity across axes:

#### **Level 1: Uniform Scaling**
- **Pattern:** Same scale factor for X, Y, and Z
- **Why Easy:** Single scalar multiplication, preserves proportions
- **Matrix Impact:** Same value on diagonal (except bottom-right)
- **Example:** Scale by (2, 2, 2)

#### **Level 2: Two-Axis Non-Uniform**
- **Pattern:** Two axes have same scale, one differs
- **Why Moderate:** Requires tracking two different scaling factors
- **Matrix Impact:** Two same diagonal values, one different
- **Example:** Scale by (1.5, 1.5, 0.5)

#### **Level 3: Three-Axis Non-Uniform**
- **Pattern:** All three axes have different scale factors
- **Why Hard:** Maximum complexity, changes object proportions significantly
- **Matrix Impact:** Three different diagonal values
- **Example:** Scale by (2, 0.5, 1.8)

---

## Weighted Score Calculation

The final difficulty score is a weighted sum:

```
Weighted Score = (Rotation Score × 0.4) + (Translation Score × 0.3) + (Scaling Score × 0.3)
```

### Why These Weights?

- **Rotation (40%):** Most mathematically complex, involves trigonometry
- **Translation (30%):** Moderate complexity, vector addition
- **Scaling (30%):** Moderate complexity, scalar multiplication

### Score Range

- **Minimum:** 0.3 (all Level 1 aspects: 1×0.4 + 1×0.3 + 1×0.3)
- **Maximum:** 3.0 (all Level 3 aspects: 3×0.4 + 3×0.3 + 3×0.3)
- **Typical Easy:** 0.8 - 1.2
- **Typical Medium:** 1.5 - 2.0
- **Typical Hard:** 2.2 - 2.8

---

## Balanced Version Generation

### Algorithm

1. **Define Target Difficulty:** Set desired weighted score (e.g., 2.0)
2. **Set Tolerance:** Define acceptable variance (e.g., ±0.3)
3. **Generate Candidates:** Create random transformation parameters
4. **Calculate Score:** Compute difficulty for each candidate
5. **Filter:** Keep only versions within tolerance
6. **Repeat:** Continue until desired number of versions are found

### Example

**Target:** 2.0, **Tolerance:** ±0.3, **Count:** 3

**Version 1 (Score: 1.9)**
- Rotation: 60° around Y-axis (Level 2, 0.4 × 2 = 0.8)
- Translation: (2, -1, 3) - three-axis (Level 3, 0.3 × 3 = 0.9)
- Scaling: (1.5, 1.5, 1.5) - uniform (Level 1, 0.3 × 1 = 0.3)
- **Total: 0.8 + 0.9 + 0.3 = 2.0** ✅

**Version 2 (Score: 2.1)**
- Rotation: 37° around X-axis (Level 3, 0.4 × 3 = 1.2)
- Translation: (0, 3, 0) - single-axis (Level 1, 0.3 × 1 = 0.3)
- Scaling: (2, 2, 1) - two-axis non-uniform (Level 2, 0.3 × 2 = 0.6)
- **Total: 1.2 + 0.3 + 0.6 = 2.1** ✅

**Version 3 (Score: 1.9)**
- Rotation: 90° around Z-axis (Level 1, 0.4 × 1 = 0.4)
- Translation: (2.5, -1.3, 4.2) - three-axis (Level 3, 0.3 × 3 = 0.9)
- Scaling: (2, 1, 3) - three-axis non-uniform (Level 3, 0.3 × 3 = 0.9)
- **Total: 0.4 + 0.9 + 0.9 = 2.2** ✅

All three versions are within ±0.3 of target 2.0, ensuring fairness!

---

## JSON Export Format

```json
{
  "exam_versions": [
    {
      "question_id": "composite_transform_1735920000_123",
      "parameters": {
        "rotation_angle": 60,
        "rotation_axis": "(0, 1, 0)",
        "translation": [2, -1, 3],
        "scaling": [1.5, 1.5, 1.5]
      },
      "difficulty_score": 2.0,
      "difficulty_breakdown": {
        "aspects": [
          {
            "name": "Rotation",
            "level": 2,
            "weight": 0.4,
            "description": "Moderate angle (60°)"
          },
          {
            "name": "Translation",
            "level": 3,
            "weight": 0.3,
            "description": "Three-axis diagonal translation"
          },
          {
            "name": "Scaling",
            "level": 1,
            "weight": 0.3,
            "description": "Uniform scaling (1.50)"
          }
        ],
        "weighted_score": 2.0
      },
      "initial_state": {
        "position": [0, 0, 0],
        "rotation": [0, 0, 0],
        "scale": [1, 1, 1],
        "shape": "cube"
      },
      "target_state": {
        "position": [2.0, -1.0, 3.0]
      },
      "solution": {
        "transformation_matrix": [
          /* 16-element matrix */
        ],
        "final_position": [2.0, -1.0, 3.0]
      },
      "question_text": "...",
      "generated_at": "2025-01-03T10:00:00.000Z"
    }
  ],
  "metadata": {
    "version_count": 3,
    "average_difficulty": 2.03,
    "difficulty_range": {
      "min": 1.9,
      "max": 2.2
    },
    "generated_at": "2025-01-03T10:00:00.000Z"
  }
}
```

---

## Validation & Quality Assurance

### Ensuring Fairness

1. **Statistical Analysis:** Monitor difficulty distribution across generated versions
2. **Variance Threshold:** Flag exam sets with variance > 0.5 for review
3. **Manual Review:** Periodically verify that difficulty levels match actual student performance
4. **Calibration:** Adjust weights based on grading data

### Preventing Gaming

Students cannot "game" the system because:
- Parameter space is continuous and vast
- Difficulty scoring is transparent but not predictable
- Each aspect combines in complex ways
- Memorizing patterns doesn't help with novel combinations

---

## Future AI Integration (Placeholders Added)

### Phase 2: Question Text Paraphrasing
```typescript
// Placeholder in: src/lib/difficulty.ts
async function paraphraseQuestionText(originalText: string): Promise<string>
```

**Purpose:** Generate varied wording while preserving mathematical content
**Example:**
- Original: "Rotate the cube 45° around the Y-axis"
- Paraphrased: "Apply a 45-degree rotation to the cube about the vertical axis"

### Phase 3: Visual Variation
```typescript
// Placeholder in: src/lib/difficulty.ts
async function generateVariedRendering(baseCode: string): Promise<string>
```

**Purpose:** Vary lighting, camera angles, colors while keeping transformations identical
**Example:**
- Version A: Blue cube, front view, soft lighting
- Version B: Green cube, angled view, dramatic lighting
- Both have identical transformation mathematics

---

## Usage Guide

### For Instructors

1. **Access Balanced Version Generator:**
   - Navigate to "Balanced Versions" tab
   - Select question template (e.g., "Composite Transformation")

2. **Configure Generation:**
   - Set number of versions (recommended: 3-5)
   - Choose target difficulty (1.0 = easy, 2.0 = medium, 2.5 = hard)
   - Set tolerance (0.2-0.3 recommended)

3. **Generate & Review:**
   - Click "Generate Balanced Versions"
   - Review difficulty breakdown for each version
   - Check variance is acceptable (< 0.3 for excellent fairness)

4. **Export:**
   - Click "Export JSON" to download
   - Import into LMS or exam software
   - Questions are ready for distribution

### For Developers

```typescript
import { calculateDifficulty } from '@/lib/difficulty';
import { QuestionGenerator } from '@/lib/generator';

// Generate a question
const generator = new QuestionGenerator();
const question = generator.generateQuestion('composite_transform', 12345);

// Calculate difficulty
const difficulty = calculateDifficulty(question.transformationParameters);
console.log(`Difficulty Score: ${difficulty.weightedScore}`);
console.log('Breakdown:', difficulty.aspects);
```

---

## Research & Validation

This difficulty model is based on:
- Educational assessment best practices
- Cognitive load theory
- Mathematical complexity analysis
- Instructor feedback from COMPSCI 373

Further validation through:
- Student performance correlation studies
- Expert review by graphics instructors
- Psychometric analysis of question difficulty

---

## Contact & Support

For questions about the difficulty model:
- Review code: `src/lib/difficulty.ts`
- Check examples: "Balanced Versions" tab in application
- Read export format: Sample JSON files

**Version:** 1.0  
**Last Updated:** January 2025  
**Status:** Production Ready
