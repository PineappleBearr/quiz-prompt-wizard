// Core types for the OpenGL exam question generator

export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Matrix4x4 {
  elements: number[]; // 16-element array representing 4x4 matrix
}

export interface TransformationParameters {
  translation?: Vector3;
  rotation?: {
    axis: Vector3;
    angle: number; // in degrees
  };
  scaling?: Vector3;
}

export interface Shape {
  type: 'cube' | 'sphere' | 'teapot' | 'torus' | 'cylinder';
  position: Vector3;
  rotation: Vector3;
  scale: Vector3;
  color: string;
}

export interface QuestionTemplate {
  id: string;
  name: string;
  type: 'transformation' | 'lighting' | 'hierarchy' | 'raytracing';
  difficulty: 'easy' | 'medium' | 'hard';
  description: string;
  parameterRanges: {
    translation?: {
      x: [number, number];
      y: [number, number];
      z: [number, number];
    };
    rotation?: {
      angle: [number, number];
      axes: Vector3[];
    };
    scaling?: {
      x: [number, number];
      y: [number, number];
      z: [number, number];
    };
    shapes: Shape['type'][];
  };
  gradingCriteria: {
    tolerance: number;
    requiredAccuracy: 'exact' | 'approximate';
    pointsTotal: number;
  };
}

export interface QuestionInstance {
  id: string;
  templateId: string;
  seed: number;
  questionText: string;
  initialShape: Shape;
  targetShape: Shape;
  transformationParameters: TransformationParameters;
  referenceSolution: {
    matrix: Matrix4x4;
    finalPosition: Vector3;
  };
  difficulty: QuestionTemplate['difficulty'];
  pointsTotal: number;
  generatedAt: Date;
  difficultyScore?: number; // Quantitative difficulty score
  difficultyBreakdown?: {
    aspects: Array<{
      name: string;
      score: number;
      weight: number;
      level: number;
      description: string;
    }>;
    totalScore: number;
    weightedScore: number;
  };
}

export interface ValidationResult {
  passed: boolean;
  score: number;
  maxScore: number;
  errors: string[];
  feedback: string;
}

export interface ExamConfiguration {
  questionCount: number;
  difficulty: QuestionTemplate['difficulty'];
  topicMix: {
    transformation: number;
    lighting?: number;
    hierarchy?: number;
    raytracing?: number;
  };
  randomSeed?: number;
}