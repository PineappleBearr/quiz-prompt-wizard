import React from "react";
import { RaySphereQuestion } from "../components/RaySphereQuestion";

const RaySphereDemo: React.FC = () => (
    <div style={{ padding: 32 }}>
        <RaySphereQuestion />
    </div>
);

export default RaySphereDemo;