﻿// src/routes/Index.tsx（或你的 Index 文件路径）

import { ExamGenerator } from "@/components/ExamGenerator";
import { useNavigate } from "react-router-dom";

export default function Index() {
    const navigate = useNavigate();

    return (
        <div className="p-4 space-y-4">
            {/* 原有内容：题目生成器 */}
            <ExamGenerator />

            {/* 新增内容：跳转到 Ray–Sphere 演示 */}
            <button onClick={() => navigate("/ray-sphere")}>
                Ray–Sphere Intersection Demo
            </button>
        </div>
    );
}
