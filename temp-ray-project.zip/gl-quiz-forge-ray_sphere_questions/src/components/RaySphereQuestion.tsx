﻿import React, { useMemo, useState } from "react";
import {
  generateRaySphereQuestion,
  raySphereIntersection,
  chooseHitAndReason,
  EPS,
  rhoFor,
  makeTangentDirection,
  perturbDirectionEuler,
} from "../logic/raysphere";
import { gradeRaySphere } from "../logic/grading";
import {
  RaySphereQuestionData,
  RaySphereStudentAnswer,
  DeltaSign,
  Sphere,
  Ray,
} from "../types/raySphereTypes";
import { RaySphereVisualizer } from "./RaySphereVisualizer";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import "katex/dist/katex.min.css";
import { BlockMath } from "react-katex";

/* ---------- A-only prompt (reworked for Scheme A) ---------- */
const APPLY_PROMPT =
  "Step 1 – Closest distance: From the picture, compare the closest distance ρ from the ray to the sphere center with the radius r. Pick the relation that holds.\n" +
  "Step 2 – Discriminant: From your choice, pick the sign of Δ.\n" +
  "Step 3 – Consequence & hit: State what your Δ implies and whether there is a forward hit (t ≥ 0 along +d).";

const RHO_REL_OPTIONS = [
  { value: "GT", label: "ρ > r" },
  { value: "EQ", label: "ρ = r" },
  { value: "LT", label: "ρ < r" },
] as const;

const DELTA_SIGN_OPTIONS: { value: DeltaSign; label: string }[] = [
  { value: "NEG", label: "Δ < 0" },
  { value: "ZERO", label: "Δ = 0" },
  { value: "POS", label: "Δ > 0" },
];
const DELTA_MEANING_OPTIONS = [
  { value: "NO_REAL_ROOTS", label: "no real roots" },
  { value: "TANGENT", label: "tangent (single contact)" },
  { value: "TWO_ROOTS", label: "two real roots" },
] as const;

/* 可选：一句话简答的主因（保留，但不再考“为什么是二次”，只做解释型补充） */
const QUADRATIC_REASON_OPTIONS = [
  { value: "RHO_REASON", label: "Use ρ vs r: ρ<r ⇒ Δ>0; ρ=r ⇒ Δ=0; ρ>r ⇒ Δ<0" },
  { value: "SUBSTITUTE", label: "Substitute p(t)=o+td; Δ sign reveals miss/tangent/two hits" },
] as const;

export const RaySphereQuestion: React.FC<{ initialLevel?: "A" | "B" | "C" }> = ({
  initialLevel = "A",
}) => {
  const [question, setQuestion] = useState<RaySphereQuestionData>(() =>
    generateRaySphereQuestion(initialLevel)
  );

  /* ===== A ===== */
  const [rhoRel, setRhoRel] = useState<(typeof RHO_REL_OPTIONS)[number]["value"]>("LT");
  const [applyReason, setApplyReason] = useState<string>(QUADRATIC_REASON_OPTIONS[0].value);
  const [applyLine, setApplyLine] = useState<string>("");
  const [applyDeltaSign, setApplyDeltaSign] = useState<DeltaSign>("POS");
  const [applyDeltaMeaning, setApplyDeltaMeaning] = useState<string>("TWO_ROOTS");
  const [applyHitYes, setApplyHitYes] = useState<string>("yes");

  /* ===== B (Tangency Hunter) ===== */
  const [yaw, setYaw] = useState<number>(0);
  const [pitch, setPitch] = useState<number>(0);
  const [bExplain, setBExplain] = useState<string>("");

  const snapNearTangent = () => {
    const dTan = makeTangentDirection(
      question.ray.origin,
      question.sphere.center,
      question.sphere.radius,
      1
    );
    if (dTan) {
      setQuestion({ ...question, ray: { origin: question.ray.origin, direction: dTan } } as any);
      setYaw(0);
      setPitch(0);
    }
  };
  const adjustedRay: Ray = useMemo(() => {
    const d = perturbDirectionEuler(question.ray.direction, yaw, pitch);
    return { origin: question.ray.origin, direction: d };
  }, [question.ray, yaw, pitch]);

  const rhoInfo = useMemo(() => rhoFor(adjustedRay, question.sphere), [adjustedRay, question.sphere]);
  const rhoGap = Math.abs(rhoInfo.rho - question.sphere.radius);
  const EPS_RHO = 1e-3;

  /* ===== C ===== */
  const [selectedIds, setSelectedIds] = useState<string>("");
  const [hitOrder, setHitOrder] = useState<string>("");
  const [firstHitId, setFirstHitId] = useState<string>("");
  const [firstHitT, setFirstHitT] = useState<string>("");
  const [tieJustify, setTieJustify] = useState<string>("");

  const [grading, setGrading] = useState<any>(null);
  const [showTLabels, setShowTLabels] = useState(true);

  /* ===== reference (A only) ===== */
  const roots = raySphereIntersection(question.ray, question.sphere);
  const { hitT } = chooseHitAndReason(roots, {
    tWindow: question.tWindow,
    epsilon: Math.max(question.tolerance, EPS),
    treatTangentAsHit: true,
  });
  const tRef = hitT;

  const handleNew = (level: "A" | "B" | "C") => {
    const q = generateRaySphereQuestion(level);
    setQuestion(q);
    setGrading(null);

    // A
    setRhoRel("LT");
    setApplyReason(QUADRATIC_REASON_OPTIONS[0].value);
    setApplyLine("");
    setApplyDeltaSign("POS");
    setApplyDeltaMeaning("TWO_ROOTS");
    setApplyHitYes("yes");
    // B
    setYaw(0);
    setPitch(0);
    setBExplain("");
    // C
    setSelectedIds("");
    setHitOrder("");
    setFirstHitId("");
    setFirstHitT("");
    setTieJustify("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ans: RaySphereStudentAnswer = {};
    if (question.level === "A") {
      ans.deltaSign = applyDeltaSign;
      ans.hit = applyHitYes === "yes";
      ans.explanation = `[rhoRel:${rhoRel}] [reason:${applyReason}] ${applyLine} | Δ implies: ${applyDeltaMeaning}`;
    } else if (question.level === "B") {
      ans.explanation = `Tangency: |rho-r|=${rhoGap.toExponential(2)}; user:${bExplain}`;
    } else if (question.level === "C") {
      ans.evaluationExplanation = `chosen:${selectedIds} | order:${hitOrder} | first:${firstHitId}@${firstHitT} | tie:${tieJustify}`;
    }
    const result = gradeRaySphere(question, ans);
    setGrading(result);
  };

  const extraSpheres: Sphere[] = useMemo(() => {
    if (Array.isArray(question.spheres) && question.spheres.length > 1) {
      return question.spheres.slice(1);
    }
    return [];
  }, [question.spheres]);
  const sphereLabel = (idx: number) => String.fromCharCode("a".charCodeAt(0) + idx);

  const CFormulas = (
    <div className="text-xs mt-2 space-y-1">
      <div><b>Ray:</b> p(t) = o + t d</div>
      <div><b>Projection:</b> m = (c − o) · d</div>
      <div><b>Perpendicular distance:</b> ρ = ‖(c − o) − m d‖</div>
      <div><b>Selection:</b> choose smallest t ≥ 0; tangent counts as hit</div>
      <div><b>Window test:</b> valid iff t ∈ [a, b] within ε</div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold mb-4">Ray–Sphere Interactive Questions</h2>

      {/* Level selector & toggles */}
      <div className="flex flex-wrap gap-4 mb-2">
        <span className="font-medium">Select Level:</span>
        <Button variant={question.level === "A" ? "default" : "outline"} onClick={() => handleNew("A")}>Level A (Apply)</Button>
        <Button variant={question.level === "B" ? "default" : "outline"} onClick={() => handleNew("B")}>Level B (Tangency Hunter)</Button>
        <Button variant={question.level === "C" ? "default" : "outline"} onClick={() => handleNew("C")}>Level C (Evaluate)</Button>

        <Button variant="outline" onClick={() => setShowTLabels(v => !v)}>
          {showTLabels ? "Hide t labels" : "Show t labels"}
        </Button>
        {question.level === "B" && (
          <Button variant="outline" onClick={snapNearTangent}>Near Tangent baseline</Button>
        )}
      </div>

      <Separator className="my-2" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left */}
        <div className="min-w-0">
          {/* Instruction */}
          <div className="mb-4 p-3 bg-[#f5faff] border border-[#e0e7ef] rounded">
            <div className="font-semibold text-[#1976d2] mb-1">Instruction</div>
            <div className="text-sm text-[#1f2937] whitespace-pre-line">
              {question.level === "A" && (
                <>
                  <div className="mb-1">{APPLY_PROMPT}</div>
                  <div className="mt-2">
                    <div className="text-xs font-medium mb-1">Reference (no numeric work required):</div>
                    <BlockMath math={String.raw`p(t)=o+t\,d`} />
                    <BlockMath math={String.raw`\rho=\| (c-o) - ((c-o)\cdot d)\,d \|`} />
                    <BlockMath math={String.raw`\rho>r\Rightarrow \Delta<0;\ \rho=r\Rightarrow \Delta=0;\ \rho<r\Rightarrow \Delta>0`} />
                    <div className="text-xs text-muted-foreground mt-1">
                      Hint: judge visually (closest distance vs radius), then complete Δ and Hit.
                    </div>
                  </div>
                </>
              )}
              {question.level === "B" && (
                <>
                  <div className="font-medium">Analyze – Tangency Hunter</div>
                  <div className="mt-1">
                    Required formulas:
                    <ul className="list-disc pl-5 mt-1">
                      <li>p(t) = o + t d</li>
                      <li>m = (c − o) · d</li>
                      <li>ρ = ‖(c − o) − m d‖</li>
                      <li>Tangency iff ρ = r</li>
                    </ul>
                    <div className="mt-2">
                      Hint: use the top button to snap near a tangent baseline, then fine-tune yaw/pitch.
                      Explain how the formulas indicate exact tangency, and describe which variable relationships must hold at tangency.
                    </div>
                    <div className="text-xs mt-2">
                      HUD: ρ = {rhoInfo.rho.toFixed(4)} | r = {question.sphere.radius.toFixed(4)} | |ρ−r| = {rhoGap.toExponential(2)} (target &lt; {EPS_RHO})
                    </div>
                  </div>
                </>
              )}
              {question.level === "C" && (
                <>
                  <div className="font-medium">Evaluate with t-window and four spheres</div>
                  <ol className="list-decimal pl-5 mt-1 space-y-1">
                    <li>Filter out spheres whose all hits fall outside [a,b].</li>
                    <li>From the remaining, decide which can be hit within [a,b].</li>
                    <li>Determine the first valid hit (sphere id and t), tangent counts as a hit.</li>
                    <li>If two hits are within ε, explain your tie-break according to the policy.</li>
                  </ol>
                  <div className="mt-2">
                    <b>Formulas:</b>
                    {CFormulas}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Parameters + Glossary */}
          <div className="mb-4 p-3 bg-[#fafbfd] border border-[#e6ecf5] rounded text-sm">
            <div className="font-semibold text-[#4b5563] mb-2">Parameters</div>
            <div>o: <span className="font-mono">{`[${question.ray.origin.map(n => n.toFixed(2)).join(", ")}]`}</span></div>
            <div>d (unit): <span className="font-mono">{`[${question.ray.direction.map(n => n.toFixed(2)).join(", ")}]`}</span></div>
            <div>c: <span className="font-mono">{`[${question.sphere.center.map(n => n.toFixed(2)).join(", ")}]`}</span></div>
            <div>r: <span className="font-mono">{question.sphere.radius.toFixed(2)}</span></div>

            {question.level === "C" && question.policy && (
              <>
                <div className="mt-2 font-medium">Window & Policy</div>
                <div>t-window [a,b]: <span className="font-mono">{`${question.policy.tWindow![0].toFixed(3)} ~ ${question.policy.tWindow![1].toFixed(3)}`}</span></div>
                <div>ε (tolerance): <span className="font-mono">{question.policy.epsilon.toExponential(1)}</span></div>
                <div className="text-xs text-muted-foreground mt-1">
                  <b>t-window</b> is the valid depth range. A hit is valid only if its smallest non-negative t lies within [a,b] (with ε boundary slack).
                  <br/><b>ε</b> is used for: forward threshold (t ≥ ε), window boundary slack (t ≥ a−ε and t ≤ b+ε), and tie (|t₁−t₂| ≤ ε).
                </div>
              </>
            )}

            {question.level === "A" && (
              <div className="mt-2 text-xs text-[#4b5563]">
                <div className="font-medium mb-1">Glossary (quick meanings)</div>
                <ul className="list-disc pl-5 space-y-0.5">
                  <li><b>o</b>: ray origin (start point)</li>
                  <li><b>d</b>: ray direction (unit vector)</li>
                  <li><b>c</b>, <b>r</b>: sphere center and radius</li>
                  <li><b>p(t)</b>=o+td: point on the ray after distance t along +d</li>
                  <li><b>ρ</b>: closest distance from c to the ray line</li>
                  <li><b>Δ</b>: discriminant; its sign decides miss/tangent/two hits</li>
                </ul>
              </div>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* A */}
            {question.level === "A" && (
              <>
                <div className="space-y-2">
                  <Label>Step 1. ρ vs r</Label>
                  <select
                    value={rhoRel}
                    onChange={(e)=>setRhoRel(e.target.value as typeof rhoRel)}
                    className="w-full bg-muted rounded p-2 text-sm"
                  >
                    {RHO_REL_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Step 2. Choose the sign of Δ</Label>
                  <select
                    value={applyDeltaSign}
                    onChange={(e) => setApplyDeltaSign(e.target.value as DeltaSign)}
                    className="w-full bg-muted rounded p-2 text-sm"
                  >
                    {DELTA_SIGN_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Step 3a. What does your Δ imply?</Label>
                  <select
                    value={applyDeltaMeaning}
                    onChange={(e) => setApplyDeltaMeaning(e.target.value)}
                    className="w-full bg-muted rounded p-2 text-sm"
                  >
                    {DELTA_MEANING_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Step 3b. Forward hit in +d (t ≥ 0)?</Label>
                  <select
                    value={applyHitYes}
                    onChange={(e) => setApplyHitYes(e.target.value)}
                    className="w-full bg-muted rounded p-2 text-sm"
                  >
                    <option value="yes">Yes — visible forward hit</option>
                    <option value="no">No — miss or behind</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label>Optional: one-line explanation</Label>
                  <Input
                    value={applyLine}
                    onChange={e => setApplyLine(e.target.value)}
                    placeholder="e.g., ρ<r ⇒ Δ>0 (two roots); choose smallest t≥0 for the visible hit."
                  />
                  <div className="text-xs text-muted-foreground">
                    Tip: {`{ρ>r, ρ=r, ρ<r}`} ↔ {`{Δ<0, Δ=0, Δ>0}`} ↔ {`{miss, tangent, two hits}`}
                  </div>
                </div>
              </>
            )}

            {/* B */}
            {question.level === "B" && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Yaw (±3°)</Label>
                    <input type="range" min={-3} max={3} step={0.1} value={yaw} onChange={(e)=>setYaw(parseFloat(e.target.value))} className="w-full" />
                  </div>
                  <div>
                    <Label>Pitch (±3°)</Label>
                    <input type="range" min={-3} max={3} step={0.1} value={pitch} onChange={(e)=>setPitch(parseFloat(e.target.value))} className="w-full" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Explain how you judge exact tangency</Label>
                  <Input value={bExplain} onChange={(e)=>setBExplain(e.target.value)}
                    placeholder="e.g., when ρ = r within tolerance, there is exactly one contact (tangent)" />
                </div>
              </>
            )}

            {/* C */}
            {question.level === "C" && (
              <>
                <div className="space-y-2">
                  <Label>Pick spheres valid within [a,b] (comma letters)</Label>
                  <Input value={selectedIds} onChange={(e)=>setSelectedIds(e.target.value)} placeholder="e.g., a,c,d" />
                </div>
                <div className="space-y-2">
                  <Label>Order of first hits (near → far, comma letters)</Label>
                  <Input value={hitOrder} onChange={(e)=>setHitOrder(e.target.value)} placeholder="e.g., c,a,d" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>First valid hit — sphere id</Label>
                    <Input value={firstHitId} onChange={(e)=>setFirstHitId(e.target.value)} placeholder="e.g., c" />
                  </div>
                  <div className="space-y-2">
                    <Label>First valid hit — t</Label>
                    <Input value={firstHitT} onChange={(e)=>setFirstHitT(e.target.value)} placeholder="e.g., 2.14" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>If two hits are within ε, explain your tie-break</Label>
                  <Input value={tieJustify} onChange={(e)=>setTieJustify(e.target.value)} placeholder="e.g., choose the lower letter id; tangent counts as hit" />
                </div>
              </>
            )}

            <div className="pt-1">
              <Button type="submit" className="w-full">Submit</Button>
            </div>
          </form>

          {grading && (
            <div className="mt-4">
              <h4 className="font-semibold mb-2">Result (stub)</h4>
              <pre className="bg-muted rounded p-2 text-xs max-h-48 overflow-auto">
                {JSON.stringify(grading, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Right: Visualization */}
        <div className="flex flex-col items-stretch gap-4">
          <h4 className="font-semibold mb-2">Visualization</h4>
          <div className="w-full">
            <RaySphereVisualizer
              ray={question.level === "B" ? adjustedRay : question.ray}
              sphere={question.sphere}
              intersectionT={question.level === "A" ? tRef : undefined}
              showIntersection={question.level === "A" ? !!tRef : false} // C & B 不显示交点小球
              className="w-full"
              showTLabels={showTLabels}
              extraSpheres={Array.isArray(question.spheres) ? question.spheres.slice(1) : []}
            />
          </div>

          {/* C: list spheres */}
          {question.level === "C" && Array.isArray(question.spheres) && (
            <div className="text-sm bg-[#fafbfd] border border-[#e6ecf5] rounded p-3">
              <div className="font-semibold mb-2">Spheres (a–d)</div>
              <div className="space-y-1">
                {question.spheres.map((s, idx) => (
                  <div key={idx}>
                    <span className="inline-block w-5 font-mono">{sphereLabel(idx)}</span>
                    center=<span className="font-mono">[{s.center.map(n=>n.toFixed(2)).join(", ")}]</span>, r=
                    <span className="font-mono">{s.radius.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
