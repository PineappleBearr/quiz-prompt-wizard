// Main exam generator application with tabbed interface

import { useState } from 'react';
import { QuestionGeneratorInterface } from '@/components/generator/QuestionGenerator';
import { BalancedVersionGenerator } from '@/components/generator/BalancedVersionGenerator';
import { GradingInterface } from '@/components/grading/GradingInterface';
import { QuestionInstance } from '@/types/question';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BookOpen, GraduationCap, Settings, Info, Sparkles } from 'lucide-react';

export function ExamGenerator() {
  const [selectedQuestionForGrading, setSelectedQuestionForGrading] = useState<QuestionInstance | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4 max-w-7xl">
        {/* Hero Section */}
        <div className="text-center mb-8 space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-12 w-12 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
              OpenGL Exam Generator
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Generate, visualize, and grade OpenGL transformation questions for COMPSCI 373. 
            Built with React, Three.js, and modern web technologies.
          </p>
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <Badge variant="secondary" className="text-sm">React + Three.js</Badge>
            <Badge variant="secondary" className="text-sm">WebGL Rendering</Badge>
            <Badge variant="secondary" className="text-sm">Automated Grading</Badge>
            <Badge variant="secondary" className="text-sm">Difficulty Balancing</Badge>
            <Badge variant="secondary" className="text-sm">JSON Export</Badge>
          </div>
        </div>

        {/* Main Interface */}
        <Tabs defaultValue="balanced" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="balanced" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Balanced Versions
            </TabsTrigger>
            <TabsTrigger value="generator" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Single Question
            </TabsTrigger>
            <TabsTrigger value="grading" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              Solution Grader
            </TabsTrigger>
            <TabsTrigger value="about" className="flex items-center gap-2">
              <Info className="h-4 w-4" />
              About
            </TabsTrigger>
          </TabsList>

          <TabsContent value="balanced" className="space-y-6">
            <BalancedVersionGenerator />
          </TabsContent>

          <TabsContent value="generator" className="space-y-6">
            <QuestionGeneratorInterface />
          </TabsContent>

          <TabsContent value="grading" className="space-y-6">
            {selectedQuestionForGrading ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Grade Student Solution</h2>
                  <Button 
                    variant="outline" 
                    onClick={() => setSelectedQuestionForGrading(null)}
                  >
                    Select Different Question
                  </Button>
                </div>
                <GradingInterface question={selectedQuestionForGrading} />
              </div>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Solution Grader</CardTitle>
                </CardHeader>
                <CardContent className="text-center py-12">
                  <GraduationCap className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Question Selected</h3>
                  <p className="text-muted-foreground mb-6">
                    Generate a question first, then come back here to test the grading system
                  </p>
                  <Button onClick={() => {
                    // For demo purposes, create a sample question
                    const sampleQuestion: QuestionInstance = {
                      id: 'demo_question',
                      templateId: 'translation_basic',
                      seed: 12345,
                      questionText: 'Demo question for grading interface',
                      difficulty: 'medium',
                      pointsTotal: 15,
                      generatedAt: new Date(),
                      initialShape: {
                        type: 'cube',
                        position: { x: 0, y: 0, z: 0 },
                        rotation: { x: 0, y: 0, z: 0 },
                        scale: { x: 1, y: 1, z: 1 },
                        color: '#3b82f6'
                      },
                      targetShape: {
                        type: 'cube',
                        position: { x: 2, y: 1, z: -3 },
                        rotation: { x: 0, y: 0, z: 0 },
                        scale: { x: 1, y: 1, z: 1 },
                        color: '#3b82f6'
                      },
                      transformationParameters: {
                        translation: { x: 2, y: 1, z: -3 }
                      },
                      referenceSolution: {
                        matrix: {
                          elements: [1, 0, 0, 2, 0, 1, 0, 1, 0, 0, 1, -3, 0, 0, 0, 1]
                        },
                        finalPosition: { x: 2, y: 1, z: -3 }
                      }
                    };
                    setSelectedQuestionForGrading(sampleQuestion);
                  }}>
                    Try Demo Question
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="about" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="h-2 w-2 bg-accent rounded-full mt-2" />
                      <div>
                        <h4 className="font-medium">Modular Question Templates</h4>
                        <p className="text-sm text-muted-foreground">Extensible system for different OpenGL topics</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="h-2 w-2 bg-accent rounded-full mt-2" />
                      <div>
                        <h4 className="font-medium">3D Visualization</h4>
                        <p className="text-sm text-muted-foreground">Real-time WebGL rendering of transformations</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="h-2 w-2 bg-accent rounded-full mt-2" />
                      <div>
                        <h4 className="font-medium">Difficulty Balancing</h4>
                        <p className="text-sm text-muted-foreground">Quantitative scoring ensures fair assessment</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="h-2 w-2 bg-accent rounded-full mt-2" />
                      <div>
                        <h4 className="font-medium">Automated Grading</h4>
                        <p className="text-sm text-muted-foreground">Numerical validation with configurable tolerance</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="h-2 w-2 bg-accent rounded-full mt-2" />
                      <div>
                        <h4 className="font-medium">JSON Export</h4>
                        <p className="text-sm text-muted-foreground">Export questions for external exam systems</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technical Stack</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Frontend</span>
                      <Badge variant="outline">React + TypeScript</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">3D Graphics</span>
                      <Badge variant="outline">Three.js + WebGL</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">UI Framework</span>
                      <Badge variant="outline">Tailwind CSS + shadcn/ui</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Build Tool</span>
                      <Badge variant="outline">Vite</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Current Capabilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-2 text-accent">✅ Implemented</h4>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li>• Translation transformations</li>
                        <li>• Rotation around arbitrary axes</li>
                        <li>• Uniform and non-uniform scaling</li>
                        <li>• Composite transformations</li>
                        <li>• 3D visualization with WebGL</li>
                        <li>• Quantitative difficulty scoring</li>
                        <li>• Balanced version generation</li>
                        <li>• Automated solution validation</li>
                        <li>• JSON export for integration</li>
                        <li>• Reproducible question generation</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2 text-graphics-orange">🚧 Coming Soon</h4>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li>• Lighting and shading questions</li>
                        <li>• Hierarchical transformations</li>
                        <li>• Ray tracing problems</li>
                        <li>• Texture mapping exercises</li>
                        <li>• Projection matrix calculations</li>
                        <li>• View frustum questions</li>
                        <li>• Batch question generation</li>
                        <li>• Integration with LMS systems</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}