import { QuestionInstance } from '@/types/question';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download, RefreshCw } from 'lucide-react';
import { exportMultipleVersions, downloadJSON } from '@/lib/examExport';
import { Progress } from '@/components/ui/progress';
import { Scene3D } from '@/components/renderer/Scene3D';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface DifficultyComparisonProps {
  questions: QuestionInstance[];
  onRegenerate?: () => void;
}

export function DifficultyComparison({ questions, onRegenerate }: DifficultyComparisonProps) {
  if (questions.length === 0) return null;

  const handleExportJSON = () => {
    const difficulties = questions.map(q => q.difficultyBreakdown!).filter(Boolean);
    const jsonString = exportMultipleVersions(questions, difficulties as any);
    downloadJSON(jsonString, `exam_versions_${Date.now()}.json`);
  };

  const avgDifficulty = questions.reduce((sum, q) => sum + (q.difficultyScore || 0), 0) / questions.length;
  const difficultyRange = {
    min: Math.min(...questions.map(q => q.difficultyScore || 0)),
    max: Math.max(...questions.map(q => q.difficultyScore || 0))
  };
  const variance = difficultyRange.max - difficultyRange.min;

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Difficulty Comparison - {questions.length} Versions</CardTitle>
          <div className="flex gap-2">
            <Button onClick={onRegenerate} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Regenerate
            </Button>
            <Button onClick={handleExportJSON} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export JSON
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Statistics */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{avgDifficulty.toFixed(2)}</div>
              <div className="text-sm text-muted-foreground">Average Difficulty</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{variance.toFixed(2)}</div>
              <div className="text-sm text-muted-foreground">Variance</div>
              <Badge variant={variance < 0.2 ? "default" : variance < 0.4 ? "secondary" : "destructive"} className="mt-2">
                {variance < 0.2 ? "Excellent" : variance < 0.4 ? "Good" : "Needs Adjustment"}
              </Badge>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{difficultyRange.min.toFixed(2)} - {difficultyRange.max.toFixed(2)}</div>
              <div className="text-sm text-muted-foreground">Range</div>
            </CardContent>
          </Card>
        </div>

        {/* Individual Version Display with Tabs */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Individual Versions</h3>
          <Tabs defaultValue="0" className="w-full">
            <TabsList className="w-full grid grid-cols-auto" style={{ gridTemplateColumns: `repeat(${questions.length}, 1fr)` }}>
              {questions.map((_, index) => (
                <TabsTrigger key={index} value={index.toString()}>
                  Version {index + 1}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {questions.map((question, index) => (
              <TabsContent key={question.id} value={index.toString()} className="space-y-6">
                {/* Question Header */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <Badge variant="outline" className="mb-2">Version {index + 1}</Badge>
                        <div className="text-sm text-muted-foreground">ID: {question.id}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">{question.difficultyScore?.toFixed(2)}</div>
                        <div className="text-sm text-muted-foreground">Weighted Score</div>
                      </div>
                    </div>
                    
                    {/* Difficulty Breakdown */}
                    {question.difficultyBreakdown && (
                      <div className="space-y-3">
                        {question.difficultyBreakdown.aspects.map((aspect) => (
                          <div key={aspect.name} className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span className="font-medium">{aspect.name}</span>
                              <div className="flex items-center gap-2">
                                <Badge variant={aspect.level === 1 ? "secondary" : aspect.level === 2 ? "default" : "destructive"}>
                                  Level {aspect.level}
                                </Badge>
                                <span className="text-muted-foreground">Weight: {(aspect.weight * 100).toFixed(0)}%</span>
                              </div>
                            </div>
                            <Progress value={(aspect.score / 3) * 100} className="h-2" />
                            <div className="text-xs text-muted-foreground">{aspect.description}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Question Text */}
                <Card>
                  <CardHeader>
                    <CardTitle>Question</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-sm max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                        {question.questionText}
                      </pre>
                    </div>
                  </CardContent>
                </Card>

                {/* 3D Visualization */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Scene3D
                    shapes={[question.initialShape]}
                    title="Initial State"
                    className="w-full"
                  />
                  <Scene3D
                    shapes={[question.targetShape]}
                    title="Target State"
                    className="w-full"
                  />
                </div>

                {/* Transformation Parameters */}
                <Card>
                  <CardHeader>
                    <CardTitle>Transformation Parameters</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {question.transformationParameters.translation && (
                      <div>
                        <h4 className="font-medium text-sm mb-2">Translation</h4>
                        <code className="text-sm bg-muted px-2 py-1 rounded">
                          T = ({question.transformationParameters.translation.x.toFixed(2)}, {' '}
                          {question.transformationParameters.translation.y.toFixed(2)}, {' '}
                          {question.transformationParameters.translation.z.toFixed(2)})
                        </code>
                      </div>
                    )}
                    
                    {question.transformationParameters.rotation && (
                      <div>
                        <h4 className="font-medium text-sm mb-2">Rotation</h4>
                        <code className="text-sm bg-muted px-2 py-1 rounded">
                          Axis: ({question.transformationParameters.rotation.axis.x}, {' '}
                          {question.transformationParameters.rotation.axis.y}, {' '}
                          {question.transformationParameters.rotation.axis.z}), {' '}
                          Angle: {question.transformationParameters.rotation.angle.toFixed(1)}°
                        </code>
                      </div>
                    )}
                    
                    {question.transformationParameters.scaling && (
                      <div>
                        <h4 className="font-medium text-sm mb-2">Scaling</h4>
                        <code className="text-sm bg-muted px-2 py-1 rounded">
                          S = ({question.transformationParameters.scaling.x.toFixed(2)}, {' '}
                          {question.transformationParameters.scaling.y.toFixed(2)}, {' '}
                          {question.transformationParameters.scaling.z.toFixed(2)})
                        </code>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
}
