// 3D Scene renderer using React Three Fiber

import { Canvas } from '@react-three/fiber';
import { OrbitControls, Grid, Text, Box, Sphere, Torus, Cylinder, Line } from '@react-three/drei';
import { Shape } from '@/types/question';
import { Suspense } from 'react';

interface Scene3DProps {
  shapes: Shape[];
  showAxes?: boolean;
  showGrid?: boolean;
  title?: string;
  className?: string;
}

interface ShapeComponentProps {
  shape: Shape;
}

function ShapeComponent({ shape }: ShapeComponentProps) {
  const { type, position, rotation, scale, color } = shape;

  const shapeProps = {
    position: [position.x, position.y, position.z] as [number, number, number],
    rotation: [
      (rotation.x * Math.PI) / 180,
      (rotation.y * Math.PI) / 180,
      (rotation.z * Math.PI) / 180
    ] as [number, number, number],
    scale: [scale.x, scale.y, scale.z] as [number, number, number]
  };

  const material = <meshStandardMaterial color={color} />;

  switch (type) {
    case 'cube':
      return (
        <Box {...shapeProps}>
          {material}
        </Box>
      );
    case 'sphere':
      return (
        <Sphere {...shapeProps} args={[1, 32, 32]}>
          {material}
        </Sphere>
      );
    case 'torus':
      return (
        <Torus {...shapeProps} args={[1, 0.4, 16, 100]}>
          {material}
        </Torus>
      );
    case 'cylinder':
      return (
        <Cylinder {...shapeProps} args={[0.5, 0.5, 2, 32]}>
          {material}
        </Cylinder>
      );
    case 'teapot':
      // For now, use a torus as teapot placeholder
      return (
        <Torus {...shapeProps} args={[0.8, 0.3, 8, 16]}>
          {material}
        </Torus>
      );
    default:
      return null;
  }
}

export function Scene3D({ shapes, showAxes = true, showGrid = true, title, className }: Scene3DProps) {
  return (
    <div className={className}>
      {title && (
        <div className="mb-2 text-center">
          <h4 className="text-sm font-medium text-foreground">{title}</h4>
        </div>
      )}
      <div className="h-64 w-full rounded-lg border bg-card shadow-sm overflow-hidden">
        <Canvas 
          orthographic
          camera={{ 
            position: [0, 0, 10], 
            zoom: 30,
            up: [0, 1, 0],
            near: 0.1,
            far: 1000
          } as any}
        >
          <Suspense fallback={null}>
            {/* Lighting */}
            <ambientLight intensity={0.6} />
            <directionalLight position={[0, 0, 5]} intensity={0.8} />

            {/* XY Grid Background */}
            {showGrid && (
              <>
                {/* Grid lines */}
                {Array.from({ length: 21 }, (_, i) => i - 10).map((i) => (
                  <group key={`grid-${i}`}>
                    {/* Horizontal lines */}
                    <Line
                      points={[[-10, i, 0], [10, i, 0]]}
                      color={i === 0 ? "#6b7280" : "#374151"}
                      lineWidth={i === 0 ? 2 : 0.5}
                      opacity={0.3}
                      transparent
                    />
                    {/* Vertical lines */}
                    <Line
                      points={[[i, -10, 0], [i, 10, 0]]}
                      color={i === 0 ? "#6b7280" : "#374151"}
                      lineWidth={i === 0 ? 2 : 0.5}
                      opacity={0.3}
                      transparent
                    />
                  </group>
                ))}
              </>
            )}

            {showAxes && (
              <>
                {/* X-axis (Red) */}
                <Line
                  points={[[-10, 0, 0], [10, 0, 0]]}
                  color="#ef4444"
                  lineWidth={3}
                />
                {/* Arrow for X-axis */}
                <mesh position={[10, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
                  <coneGeometry args={[0.15, 0.4, 8]} />
                  <meshBasicMaterial color="#ef4444" />
                </mesh>
                
                {/* Y-axis (Green) */}
                <Line
                  points={[[0, -10, 0], [0, 10, 0]]}
                  color="#10b981"
                  lineWidth={3}
                />
                {/* Arrow for Y-axis */}
                <mesh position={[0, 10, 0]} rotation={[0, 0, 0]}>
                  <coneGeometry args={[0.15, 0.4, 8]} />
                  <meshBasicMaterial color="#10b981" />
                </mesh>
              </>
            )}

            {/* Render shapes */}
            {shapes.map((shape, index) => (
              <ShapeComponent key={index} shape={shape} />
            ))}

            {/* Axis labels */}
            {showAxes && (
              <>
                <Text
                  position={[10.5, 0, 0]}
                  fontSize={0.5}
                  color="#ef4444"
                  anchorX="left"
                  anchorY="middle"
                >
                  X
                </Text>
                <Text
                  position={[0, 10.5, 0]}
                  fontSize={0.5}
                  color="#10b981"
                  anchorX="center"
                  anchorY="bottom"
                >
                  Y
                </Text>
                
                {/* Grid number labels */}
                {[-8, -6, -4, -2, 2, 4, 6, 8].map((num) => (
                  <group key={`label-${num}`}>
                    <Text
                      position={[num, -0.5, 0]}
                      fontSize={0.3}
                      color="#9ca3af"
                      anchorX="center"
                      anchorY="top"
                    >
                      {num}
                    </Text>
                    <Text
                      position={[-0.5, num, 0]}
                      fontSize={0.3}
                      color="#9ca3af"
                      anchorX="right"
                      anchorY="middle"
                    >
                      {num}
                    </Text>
                  </group>
                ))}
              </>
            )}

            {/* Controls - limited for front view */}
            <OrbitControls
              enablePan={true}
              enableZoom={true}
              enableRotate={false}
              minZoom={10}
              maxZoom={100}
            />
          </Suspense>
        </Canvas>
      </div>
    </div>
  );
}