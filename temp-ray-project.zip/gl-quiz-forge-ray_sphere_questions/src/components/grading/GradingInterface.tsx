// Grading interface for validating student solutions

import { useState } from 'react';
import { QuestionValidator } from '@/lib/validator';
import { QuestionInstance, Matrix4x4, Vector3, ValidationResult } from '@/types/question';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, XCircle, Upload, FileText } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface GradingInterfaceProps {
  question: QuestionInstance;
}

export function GradingInterface({ question }: GradingInterfaceProps) {
  const [matrixInput, setMatrixInput] = useState('');
  const [positionInput, setPositionInput] = useState('');
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState(false);

  const validator = new QuestionValidator();

  const parseMatrix = (input: string): Matrix4x4 | null => {
    try {
      // Remove extra whitespace and split by lines or commas
      const cleanInput = input.trim().replace(/\s+/g, ' ');
      const numbers = cleanInput.split(/[,\s\n]+/).map(str => parseFloat(str.trim()));
      
      if (numbers.length !== 16) {
        throw new Error(`Expected 16 matrix elements, got ${numbers.length}`);
      }
      
      if (numbers.some(isNaN)) {
        throw new Error('Invalid number in matrix');
      }

      return { elements: numbers };
    } catch (error) {
      toast({
        title: "Invalid matrix format",
        description: error instanceof Error ? error.message : "Please check your matrix input",
        variant: "destructive"
      });
      return null;
    }
  };

  const parsePosition = (input: string): Vector3 | null => {
    try {
      const cleanInput = input.trim().replace(/[()]/g, '');
      const numbers = cleanInput.split(/[,\s]+/).map(str => parseFloat(str.trim()));
      
      if (numbers.length !== 3) {
        throw new Error(`Expected 3 position coordinates, got ${numbers.length}`);
      }
      
      if (numbers.some(isNaN)) {
        throw new Error('Invalid number in position');
      }

      return { x: numbers[0], y: numbers[1], z: numbers[2] };
    } catch (error) {
      toast({
        title: "Invalid position format",
        description: error instanceof Error ? error.message : "Please check your position input",
        variant: "destructive"
      });
      return null;
    }
  };

  const handleValidate = () => {
    if (!matrixInput.trim() && !positionInput.trim()) {
      toast({
        title: "No solution provided",
        description: "Please enter either a transformation matrix or final position",
        variant: "destructive"
      });
      return;
    }

    setIsValidating(true);

    try {
      const studentMatrix = matrixInput.trim() ? parseMatrix(matrixInput) : undefined;
      const studentPosition = positionInput.trim() ? parsePosition(positionInput) : undefined;

      if (matrixInput.trim() && !studentMatrix) {
        setIsValidating(false);
        return;
      }
      
      if (positionInput.trim() && !studentPosition) {
        setIsValidating(false);
        return;
      }

      const result = validator.validateSolution(question, studentMatrix, studentPosition);
      setValidationResult(result);

      toast({
        title: result.passed ? "Validation complete" : "Validation failed",
        description: `Score: ${result.score}/${result.maxScore} (${((result.score / result.maxScore) * 100).toFixed(1)}%)`,
        variant: result.passed ? "default" : "destructive"
      });
    } catch (error) {
      toast({
        title: "Validation error",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleLoadExample = () => {
    // Load a partially correct example for demonstration
    setMatrixInput(question.referenceSolution.matrix.elements.map(val => 
      (val + (Math.random() - 0.5) * 0.1).toFixed(3)
    ).join(', '));
    
    const pos = question.referenceSolution.finalPosition;
    setPositionInput(`${(pos.x + (Math.random() - 0.5) * 0.1).toFixed(3)}, ${(pos.y + (Math.random() - 0.5) * 0.1).toFixed(3)}, ${(pos.z + (Math.random() - 0.5) * 0.1).toFixed(3)}`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Submit Student Solution
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Question Info */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-medium">Question: {question.templateId}</span>
              <Badge variant={question.difficulty === 'easy' ? 'secondary' : 
                           question.difficulty === 'medium' ? 'default' : 'destructive'}>
                {question.difficulty}
              </Badge>
              <Badge variant="outline">{question.pointsTotal} pts</Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Seed: {question.seed} | Generated: {question.generatedAt.toLocaleString()}
            </p>
          </div>

          {/* Matrix Input */}
          <div className="space-y-2">
            <Label htmlFor="matrix-input">Transformation Matrix (16 elements)</Label>
            <Textarea
              id="matrix-input"
              placeholder="Enter 16 matrix elements separated by commas or spaces:&#10;1.0, 0.0, 0.0, 2.5,&#10;0.0, 1.0, 0.0, 1.0,&#10;0.0, 0.0, 1.0, -3.0,&#10;0.0, 0.0, 0.0, 1.0"
              value={matrixInput}
              onChange={(e) => setMatrixInput(e.target.value)}
              rows={4}
              className="font-mono text-sm"
            />
          </div>

          {/* Position Input */}
          <div className="space-y-2">
            <Label htmlFor="position-input">Final Position (x, y, z)</Label>
            <Input
              id="position-input"
              placeholder="Enter final position: x, y, z (e.g., 2.5, 1.0, -3.0)"
              value={positionInput}
              onChange={(e) => setPositionInput(e.target.value)}
              className="font-mono"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button onClick={handleValidate} disabled={isValidating} className="flex-1">
              {isValidating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Validating...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Validate Solution
                </>
              )}
            </Button>
            <Button variant="outline" onClick={handleLoadExample}>
              <Upload className="h-4 w-4 mr-2" />
              Load Example
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Validation Results */}
      {validationResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {validationResult.passed ? (
                <CheckCircle className="h-5 w-5 text-accent" />
              ) : (
                <XCircle className="h-5 w-5 text-destructive" />
              )}
              Grading Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Score */}
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="font-medium">
                  {validationResult.passed ? 'PASSED' : 'FAILED'}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {((validationResult.score / validationResult.maxScore) * 100).toFixed(1)}% accuracy
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {validationResult.score}/{validationResult.maxScore}
                </div>
                <p className="text-sm text-muted-foreground">points</p>
              </div>
            </div>

            {/* Errors */}
            {validationResult.errors.length > 0 && (
              <div>
                <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                  <XCircle className="h-4 w-4 text-destructive" />
                  Issues Found
                </h4>
                <ul className="space-y-1">
                  {validationResult.errors.map((error, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      • {error}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <Separator />

            {/* Feedback */}
            <div>
              <h4 className="font-medium text-sm mb-2">Feedback</h4>
              <pre className="text-sm text-muted-foreground whitespace-pre-wrap bg-muted p-3 rounded">
                {validationResult.feedback}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}