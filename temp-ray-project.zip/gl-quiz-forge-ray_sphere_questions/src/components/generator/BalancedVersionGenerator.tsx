import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { QuestionGenerator } from '@/lib/generator';
import { QuestionInstance } from '@/types/question';
import { DifficultyComparison } from '../difficulty/DifficultyComparison';
import { Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ALL_TEMPLATES } from '@/lib/templates';

export function BalancedVersionGenerator() {
  const [loading, setLoading] = useState(false);
  const [versions, setVersions] = useState<QuestionInstance[]>([]);
  const [versionCount, setVersionCount] = useState(3);
  const [targetDifficulty, setTargetDifficulty] = useState<number>(2.0);
  const [tolerance, setTolerance] = useState<number>(0.3);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('composite_transform');

  const generateBalancedVersions = async () => {
    setLoading(true);
    try {
      const generator = new QuestionGenerator();
      const generatedVersions: QuestionInstance[] = [];
      const maxAttempts = 100;

      for (let i = 0; i < versionCount; i++) {
        let attempts = 0;
        let found = false;

        while (!found && attempts < maxAttempts) {
          const seed = Date.now() + attempts + i * 1000;
          const question = generator.generateQuestion(selectedTemplate, seed);
          
          if (question && question.difficultyScore) {
            const diff = Math.abs(question.difficultyScore - targetDifficulty);
            
            if (diff <= tolerance) {
              generatedVersions.push(question);
              found = true;
            }
          }
          
          attempts++;
        }

        if (!found) {
          toast.warning(`Version ${i + 1} exceeded max attempts. Using closest match.`);
          // Use the last generated question even if not perfect
          const seed = Date.now() + i * 1000;
          const fallbackQuestion = generator.generateQuestion(selectedTemplate, seed);
          if (fallbackQuestion) {
            generatedVersions.push(fallbackQuestion);
          }
        }
      }

      setVersions(generatedVersions);
      
      const avgDiff = generatedVersions.reduce((sum, q) => sum + (q.difficultyScore || 0), 0) / generatedVersions.length;
      const variance = Math.max(...generatedVersions.map(q => q.difficultyScore || 0)) - 
                      Math.min(...generatedVersions.map(q => q.difficultyScore || 0));
      
      toast.success(`Generated ${generatedVersions.length} balanced versions!`, {
        description: `Avg difficulty: ${avgDiff.toFixed(2)}, Variance: ${variance.toFixed(2)}`
      });
    } catch (error) {
      toast.error('Failed to generate balanced versions');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Balanced Version Generator
          </CardTitle>
          <CardDescription>
            Generate multiple exam versions with equivalent difficulty scores for fair assessment.
            The system ensures all students receive questions of similar complexity.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="template">Question Template</Label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger id="template">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ALL_TEMPLATES.map(template => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name} ({template.difficulty})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="versionCount">Number of Versions</Label>
              <Input
                id="versionCount"
                type="number"
                min={2}
                max={5}
                value={versionCount}
                onChange={(e) => setVersionCount(parseInt(e.target.value) || 3)}
              />
              <p className="text-xs text-muted-foreground">Max 5 versions for optimal performance</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetDifficulty">
                Target Difficulty Score
                <span className="text-sm text-muted-foreground ml-2">(0.3 - 3.0)</span>
              </Label>
              <Input
                id="targetDifficulty"
                type="number"
                step={0.1}
                min={0.3}
                max={3.0}
                value={targetDifficulty}
                onChange={(e) => setTargetDifficulty(parseFloat(e.target.value) || 2.0)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tolerance">
                Tolerance
                <span className="text-sm text-muted-foreground ml-2">(±)</span>
              </Label>
              <Input
                id="tolerance"
                type="number"
                step={0.05}
                min={0.05}
                max={0.5}
                value={tolerance}
                onChange={(e) => setTolerance(parseFloat(e.target.value) || 0.3)}
              />
            </div>
          </div>

          <div className="p-4 bg-muted rounded-lg space-y-2">
            <div className="text-sm font-medium">How Difficulty Scoring Works:</div>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li><strong>Rotation (40%):</strong> Level 1 (90°, 180°), Level 2 (45°, 60°), Level 3 (uncommon angles)</li>
              <li><strong>Translation (30%):</strong> Level 1 (single-axis), Level 2 (two-axis), Level 3 (three-axis)</li>
              <li><strong>Scaling (30%):</strong> Level 1 (uniform), Level 2 (two-axis), Level 3 (three-axis non-uniform)</li>
            </ul>
          </div>

          <Button 
            onClick={generateBalancedVersions} 
            disabled={loading}
            className="w-full"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Balanced Versions...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate {versionCount} Balanced Versions
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {versions.length > 0 && (
        <DifficultyComparison 
          questions={versions} 
          onRegenerate={generateBalancedVersions}
        />
      )}
    </div>
  );
}
