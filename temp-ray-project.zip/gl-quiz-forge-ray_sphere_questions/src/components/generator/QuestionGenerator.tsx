// Main question generator interface

import { useState } from 'react';
import { QuestionGenerator as Generator } from '@/lib/generator';
import { ALL_TEMPLATES, getTemplatesByDifficulty, getTemplatesByType } from '@/lib/templates';
import { QuestionInstance, QuestionTemplate } from '@/types/question';
import { QuestionView } from '@/components/question/QuestionView';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Shuffle, Settings, BookOpen, Eye } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function QuestionGeneratorInterface() {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [difficulty, setDifficulty] = useState<string>('');
  const [questionType, setQuestionType] = useState<string>('');
  const [customSeed, setCustomSeed] = useState<string>('');
  const [showSolution, setShowSolution] = useState(false);
  const [generatedQuestion, setGeneratedQuestion] = useState<QuestionInstance | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generator = new Generator();

  const handleGenerateQuestion = async () => {
    if (!selectedTemplate) {
      toast({
        title: "Please select a template",
        description: "Choose a question template to generate a question",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    
    try {
      // Use custom seed if provided, otherwise use random
      const seed = customSeed ? parseInt(customSeed) : undefined;
      const question = generator.generateQuestion(selectedTemplate, seed);
      
      if (question) {
        setGeneratedQuestion(question);
        toast({
          title: "Question generated successfully",
          description: `Generated ${question.difficulty} level question with ${question.pointsTotal} points`
        });
      } else {
        toast({
          title: "Failed to generate question",
          description: "Please check the template and try again",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error generating question",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRandomSeed = () => {
    setCustomSeed(Math.floor(Math.random() * 1000000).toString());
  };

  // Filter templates based on difficulty and type
  const filteredTemplates = ALL_TEMPLATES.filter(template => {
    const matchesDifficulty = !difficulty || difficulty === 'all' || template.difficulty === difficulty;
    const matchesType = !questionType || questionType === 'all' || template.type === questionType;
    return matchesDifficulty && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
          OpenGL Exam Question Generator
        </h1>
        <p className="text-muted-foreground text-lg">
          Generate custom transformation questions for COMPSCI 373 students
        </p>
      </div>

      {/* Generator Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Question Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Difficulty Level</Label>
              <Select value={difficulty} onValueChange={setDifficulty}>
                <SelectTrigger>
                  <SelectValue placeholder="Any difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any difficulty</SelectItem>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Question Type</Label>
              <Select value={questionType} onValueChange={setQuestionType}>
                <SelectTrigger>
                  <SelectValue placeholder="Any type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any type</SelectItem>
                  <SelectItem value="transformation">Transformation</SelectItem>
                  <SelectItem value="lighting">Lighting (Coming Soon)</SelectItem>
                  <SelectItem value="hierarchy">Hierarchy (Coming Soon)</SelectItem>
                  <SelectItem value="raytracing">Ray Tracing (Coming Soon)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Template</Label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent>
                  {filteredTemplates.map(template => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Template Info */}
          {selectedTemplate && (() => {
            const template = ALL_TEMPLATES.find(t => t.id === selectedTemplate);
            return template ? (
              <div className="p-4 bg-muted rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span className="font-medium">{template.name}</span>
                  <Badge variant={template.difficulty === 'easy' ? 'secondary' : 
                               template.difficulty === 'medium' ? 'default' : 'destructive'}>
                    {template.difficulty}
                  </Badge>
                  <Badge variant="outline">{template.gradingCriteria.pointsTotal} pts</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{template.description}</p>
              </div>
            ) : null;
          })()}

          <Separator />

          {/* Advanced Options */}
          <div className="space-y-4">
            <h4 className="font-medium">Advanced Options</h4>
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="show-solution">Show reference solution</Label>
                <p className="text-sm text-muted-foreground">Display the answer key for instructor review</p>
              </div>
              <Switch
                id="show-solution"
                checked={showSolution}
                onCheckedChange={setShowSolution}
              />
            </div>

            <div className="flex gap-2">
              <div className="flex-1 space-y-2">
                <Label htmlFor="custom-seed">Custom Seed (optional)</Label>
                <Input
                  id="custom-seed"
                  placeholder="Enter seed for reproducible questions"
                  value={customSeed}
                  onChange={(e) => setCustomSeed(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <Button variant="outline" onClick={handleRandomSeed}>
                  <Shuffle className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <Button 
            onClick={handleGenerateQuestion} 
            disabled={!selectedTemplate || isGenerating}
            className="w-full"
            size="lg"
          >
            {isGenerating ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Generating Question...
              </>
            ) : (
              <>
                <Eye className="h-4 w-4 mr-2" />
                Generate Question
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Question */}
      {generatedQuestion && (
        <QuestionView 
          question={generatedQuestion} 
          showSolution={showSolution}
        />
      )}

      {/* Template Library */}
      <Card>
        <CardHeader>
          <CardTitle>Available Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTemplates.map(template => (
              <div
                key={template.id}
                className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => setSelectedTemplate(template.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{template.name}</h4>
                  <Badge variant={template.difficulty === 'easy' ? 'secondary' : 
                               template.difficulty === 'medium' ? 'default' : 'destructive'}>
                    {template.difficulty}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{template.description}</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{template.type}</span>
                  <span>{template.gradingCriteria.pointsTotal} pts</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}