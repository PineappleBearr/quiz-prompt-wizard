// Component for displaying a generated question

import { QuestionInstance } from '@/types/question';
import { Scene3D } from '@/components/renderer/Scene3D';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Copy, Download, Eye } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface QuestionViewProps {
  question: QuestionInstance;
  showSolution?: boolean;
  onExport?: () => void;
}

export function QuestionView({ question, showSolution = false, onExport }: QuestionViewProps) {
  const handleCopyQuestion = () => {
    navigator.clipboard.writeText(question.questionText);
    toast({
      title: "Question copied",
      description: "Question text has been copied to clipboard"
    });
  };

  const handleExportJSON = () => {
    const dataStr = JSON.stringify(question, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `question_${question.id}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();

    toast({
      title: "Question exported",
      description: "Question data has been downloaded as JSON"
    });
  };

  const formatMatrix = (matrix: number[]) => {
    const rows = [];
    for (let i = 0; i < 4; i++) {
      const row = matrix.slice(i * 4, (i + 1) * 4)
        .map(val => val.toFixed(3).padStart(8))
        .join(' ');
      rows.push(row);
    }
    return rows.join('\n');
  };

  return (
    <div className="space-y-6">
      {/* Question Header */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              Question: {question.templateId}
              <Badge variant={question.difficulty === 'easy' ? 'secondary' : 
                           question.difficulty === 'medium' ? 'default' : 'destructive'}>
                {question.difficulty}
              </Badge>
              <Badge variant="outline">{question.pointsTotal} pts</Badge>
              {question.difficultyScore && (
                <Badge variant="outline" className="bg-primary/10">
                  Difficulty: {question.difficultyScore.toFixed(2)}
                </Badge>
              )}
            </CardTitle>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleCopyQuestion}>
              <Copy className="h-4 w-4 mr-1" />
              Copy
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportJSON}>
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
            {onExport && (
              <Button variant="default" size="sm" onClick={onExport}>
                <Eye className="h-4 w-4 mr-1" />
                Preview
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Question Text */}
      <Card>
        <CardHeader>
          <CardTitle>Question</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none">
            <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
              {question.questionText}
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* 3D Visualization */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Scene3D
          shapes={[question.initialShape]}
          title="Initial State"
          className="w-full"
        />
        <Scene3D
          shapes={[question.targetShape]}
          title="Target State"
          className="w-full"
        />
      </div>

      {/* Transformation Details */}
      <Card>
        <CardHeader>
          <CardTitle>Transformation Parameters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {question.transformationParameters.translation && (
            <div>
              <h4 className="font-medium text-sm mb-2">Translation</h4>
              <code className="text-sm bg-muted px-2 py-1 rounded">
                T = ({question.transformationParameters.translation.x.toFixed(2)}, {' '}
                {question.transformationParameters.translation.y.toFixed(2)}, {' '}
                {question.transformationParameters.translation.z.toFixed(2)})
              </code>
            </div>
          )}
          
          {question.transformationParameters.rotation && (
            <div>
              <h4 className="font-medium text-sm mb-2">Rotation</h4>
              <code className="text-sm bg-muted px-2 py-1 rounded">
                Axis: ({question.transformationParameters.rotation.axis.x}, {' '}
                {question.transformationParameters.rotation.axis.y}, {' '}
                {question.transformationParameters.rotation.axis.z}), {' '}
                Angle: {question.transformationParameters.rotation.angle.toFixed(1)}°
              </code>
            </div>
          )}
          
          {question.transformationParameters.scaling && (
            <div>
              <h4 className="font-medium text-sm mb-2">Scaling</h4>
              <code className="text-sm bg-muted px-2 py-1 rounded">
                S = ({question.transformationParameters.scaling.x.toFixed(2)}, {' '}
                {question.transformationParameters.scaling.y.toFixed(2)}, {' '}
                {question.transformationParameters.scaling.z.toFixed(2)})
              </code>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Difficulty Breakdown */}
      {question.difficultyBreakdown && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Difficulty Breakdown
              <Badge variant="outline">Score: {question.difficultyScore?.toFixed(2)}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              This question's difficulty is calculated based on the complexity of each transformation aspect:
            </p>
            <div className="space-y-3">
              {question.difficultyBreakdown.aspects.map((aspect) => (
                <div key={aspect.name} className="border rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{aspect.name}</span>
                    <div className="flex items-center gap-2">
                      <Badge variant={aspect.level === 1 ? "secondary" : aspect.level === 2 ? "default" : "destructive"}>
                        Level {aspect.level}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Weight: {(aspect.weight * 100).toFixed(0)}%
                      </span>
                      <span className="text-sm font-medium">
                        = {(aspect.score * aspect.weight).toFixed(2)}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{aspect.description}</p>
                </div>
              ))}
            </div>
            <div className="pt-2 border-t">
              <div className="flex items-center justify-between text-sm">
                <span>Total Score (Raw):</span>
                <span className="font-medium">{question.difficultyBreakdown.totalScore}</span>
              </div>
              <div className="flex items-center justify-between text-sm font-bold">
                <span>Weighted Score:</span>
                <span className="text-lg">{question.difficultyBreakdown.weightedScore.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Solution (if enabled) */}
      {showSolution && (
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Reference Solution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-medium text-sm mb-2">Transformation Matrix</h4>
              <pre className="text-xs bg-muted p-3 rounded font-mono overflow-x-auto">
                {formatMatrix(question.referenceSolution.matrix.elements)}
              </pre>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-medium text-sm mb-2">Final Position</h4>
              <code className="text-sm bg-muted px-2 py-1 rounded">
                ({question.referenceSolution.finalPosition.x.toFixed(3)}, {' '}
                {question.referenceSolution.finalPosition.y.toFixed(3)}, {' '}
                {question.referenceSolution.finalPosition.z.toFixed(3)})
              </code>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}