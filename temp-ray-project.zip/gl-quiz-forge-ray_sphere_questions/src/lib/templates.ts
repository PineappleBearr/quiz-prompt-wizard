// Question templates for different OpenGL topics

import { QuestionTemplate, Vector3 } from '@/types/question';

export const TRANSFORMATION_TEMPLATES: QuestionTemplate[] = [
  {
    id: 'translation_basic',
    name: 'Basic Translation',
    type: 'transformation',
    difficulty: 'easy',
    description: 'Apply a translation transformation to move an object in 3D space',
    parameterRanges: {
      translation: {
        x: [-5, 5],
        y: [-5, 5],
        z: [-5, 5]
      },
      shapes: ['cube', 'sphere']
    },
    gradingCriteria: {
      tolerance: 0.1,
      requiredAccuracy: 'approximate',
      pointsTotal: 10
    }
  },
  {
    id: 'rotation_axis',
    name: 'Rotation Around Axis',
    type: 'transformation',
    difficulty: 'medium',
    description: 'Rotate an object around a specified axis by a given angle',
    parameterRanges: {
      rotation: {
        angle: [0, 360],
        axes: [
          { x: 1, y: 0, z: 0 }, // X-axis
          { x: 0, y: 1, z: 0 }, // Y-axis
          { x: 0, y: 0, z: 1 }, // Z-axis
          { x: 1, y: 1, z: 0 }, // Diagonal axes
          { x: 1, y: 0, z: 1 },
          { x: 0, y: 1, z: 1 }
        ]
      },
      shapes: ['cube', 'teapot', 'torus']
    },
    gradingCriteria: {
      tolerance: 0.05,
      requiredAccuracy: 'approximate',
      pointsTotal: 15
    }
  },
  {
    id: 'scaling_uniform',
    name: 'Uniform Scaling',
    type: 'transformation',
    difficulty: 'easy',
    description: 'Apply uniform scaling to resize an object proportionally',
    parameterRanges: {
      scaling: {
        x: [0.5, 3.0],
        y: [0.5, 3.0],
        z: [0.5, 3.0]
      },
      shapes: ['sphere', 'cube', 'cylinder']
    },
    gradingCriteria: {
      tolerance: 0.1,
      requiredAccuracy: 'approximate',
      pointsTotal: 8
    }
  },
  {
    id: 'scaling_non_uniform',
    name: 'Non-Uniform Scaling',
    type: 'transformation',
    difficulty: 'medium',
    description: 'Apply different scaling factors to each axis',
    parameterRanges: {
      scaling: {
        x: [0.2, 4.0],
        y: [0.2, 4.0],
        z: [0.2, 4.0]
      },
      shapes: ['cube', 'cylinder', 'torus']
    },
    gradingCriteria: {
      tolerance: 0.05,
      requiredAccuracy: 'approximate',
      pointsTotal: 12
    }
  },
  {
    id: 'composite_transform',
    name: 'Composite Transformation',
    type: 'transformation',
    difficulty: 'hard',
    description: 'Apply multiple transformations in sequence (translation, rotation, scaling)',
    parameterRanges: {
      translation: {
        x: [-3, 3],
        y: [-3, 3],
        z: [-3, 3]
      },
      rotation: {
        angle: [0, 180],
        axes: [
          { x: 1, y: 0, z: 0 },
          { x: 0, y: 1, z: 0 },
          { x: 0, y: 0, z: 1 }
        ]
      },
      scaling: {
        x: [0.5, 2.0],
        y: [0.5, 2.0],
        z: [0.5, 2.0]
      },
      shapes: ['cube', 'sphere', 'teapot', 'torus']
    },
    gradingCriteria: {
      tolerance: 0.02,
      requiredAccuracy: 'exact',
      pointsTotal: 25
    }
  }
];

export const ALL_TEMPLATES: QuestionTemplate[] = [
  ...TRANSFORMATION_TEMPLATES
  // Future: lighting, hierarchy, raytracing templates
];

export function getTemplateById(id: string): QuestionTemplate | undefined {
  return ALL_TEMPLATES.find(template => template.id === id);
}

export function getTemplatesByDifficulty(difficulty: QuestionTemplate['difficulty']): QuestionTemplate[] {
  return ALL_TEMPLATES.filter(template => template.difficulty === difficulty);
}

export function getTemplatesByType(type: QuestionTemplate['type']): QuestionTemplate[] {
  return ALL_TEMPLATES.filter(template => template.type === type);
}