// Validator for grading student solutions

import { QuestionInstance, ValidationResult, Matrix4x4, Vector3 } from '@/types/question';

export class QuestionValidator {
  validateSolution(
    question: QuestionInstance,
    studentMatrix?: Matrix4x4,
    studentPosition?: Vector3
  ): ValidationResult {
    const errors: string[] = [];
    let score = 0;
    const maxScore = question.pointsTotal;
    const tolerance = this.getToleranceForDifficulty(question.difficulty);

    // Validate transformation matrix (60% of points)
    const matrixPoints = Math.floor(maxScore * 0.6);
    if (studentMatrix) {
      const matrixValid = this.validateMatrix(
        question.referenceSolution.matrix,
        studentMatrix,
        tolerance
      );
      if (matrixValid.isValid) {
        score += matrixPoints;
      } else {
        errors.push(`Matrix incorrect: ${matrixValid.error}`);
      }
    } else {
      errors.push('No transformation matrix provided');
    }

    // Validate final position (40% of points)
    const positionPoints = maxScore - matrixPoints;
    if (studentPosition) {
      const positionValid = this.validatePosition(
        question.referenceSolution.finalPosition,
        studentPosition,
        tolerance
      );
      if (positionValid.isValid) {
        score += positionPoints;
      } else {
        errors.push(`Final position incorrect: ${positionValid.error}`);
      }
    } else {
      errors.push('No final position provided');
    }

    const passed = score >= maxScore * 0.6; // 60% to pass
    const feedback = this.generateFeedback(score, maxScore, errors, question.difficulty);

    return {
      passed,
      score,
      maxScore,
      errors,
      feedback
    };
  }

  private validateMatrix(reference: Matrix4x4, student: Matrix4x4, tolerance: number): { isValid: boolean; error?: string } {
    if (!student.elements || student.elements.length !== 16) {
      return { isValid: false, error: 'Matrix must have 16 elements' };
    }

    for (let i = 0; i < 16; i++) {
      const diff = Math.abs(reference.elements[i] - student.elements[i]);
      if (diff > tolerance) {
        return {
          isValid: false,
          error: `Element at index ${i}: expected ${reference.elements[i].toFixed(3)}, got ${student.elements[i].toFixed(3)}`
        };
      }
    }

    return { isValid: true };
  }

  private validatePosition(reference: Vector3, student: Vector3, tolerance: number): { isValid: boolean; error?: string } {
    const diffX = Math.abs(reference.x - student.x);
    const diffY = Math.abs(reference.y - student.y);
    const diffZ = Math.abs(reference.z - student.z);

    if (diffX > tolerance || diffY > tolerance || diffZ > tolerance) {
      return {
        isValid: false,
        error: `Expected (${reference.x.toFixed(2)}, ${reference.y.toFixed(2)}, ${reference.z.toFixed(2)}), got (${student.x.toFixed(2)}, ${student.y.toFixed(2)}, ${student.z.toFixed(2)})`
      };
    }

    return { isValid: true };
  }

  private getToleranceForDifficulty(difficulty: string): number {
    switch (difficulty) {
      case 'easy': return 0.1;
      case 'medium': return 0.05;
      case 'hard': return 0.02;
      default: return 0.05;
    }
  }

  private generateFeedback(score: number, maxScore: number, errors: string[], difficulty: string): string {
    const percentage = (score / maxScore) * 100;
    let feedback = `Score: ${score}/${maxScore} (${percentage.toFixed(1)}%)\n\n`;

    if (percentage >= 90) {
      feedback += '🎉 Excellent work! Your solution is accurate and well-executed.';
    } else if (percentage >= 80) {
      feedback += '👍 Good work! Minor improvements needed for full marks.';
    } else if (percentage >= 60) {
      feedback += '✅ Passing grade. Review the concepts and practice more problems.';
    } else {
      feedback += '❌ Below passing threshold. Please review transformation matrices and coordinate systems.';
    }

    if (errors.length > 0) {
      feedback += '\n\n**Issues found:**\n';
      errors.forEach((error, index) => {
        feedback += `${index + 1}. ${error}\n`;
      });
    }

    feedback += `\n\n**Difficulty:** ${difficulty}`;
    
    return feedback;
  }

  // Batch validation for multiple questions
  validateBatch(results: Array<{ question: QuestionInstance; studentMatrix?: Matrix4x4; studentPosition?: Vector3 }>): ValidationResult[] {
    return results.map(result => 
      this.validateSolution(result.question, result.studentMatrix, result.studentPosition)
    );
  }
}