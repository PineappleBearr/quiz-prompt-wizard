// Question generator - creates question instances from templates

import { QuestionTemplate, QuestionInstance, Vector3, Matrix4x4, Shape, TransformationParameters } from '@/types/question';
import { getTemplateById } from './templates';
import { Matrix4, Vector3 as ThreeVector3 } from 'three';
import { calculateDifficulty } from './difficulty';

export class QuestionGenerator {
  private rng: () => number;

  constructor(seed?: number) {
    this.rng = this.createSeededRandom(seed || Date.now());
  }

  // Seeded random number generator for reproducible questions
  private createSeededRandom(seed: number): () => number {
    let state = seed;
    return () => {
      state = (state * 1664525 + 1013904223) % 4294967296;
      return state / 4294967296;
    };
  }

  private randomInRange(min: number, max: number): number {
    return min + this.rng() * (max - min);
  }

  private randomFromArray<T>(array: T[]): T {
    return array[Math.floor(this.rng() * array.length)];
  }

  generateQuestion(templateId: string, seed?: number): QuestionInstance | null {
    const template = getTemplateById(templateId);
    if (!template) return null;

    if (seed) {
      this.rng = this.createSeededRandom(seed);
    }

    const questionId = `${templateId}_${Date.now()}_${Math.floor(this.rng() * 1000)}`;
    
    // Generate random parameters based on template ranges
    const transformationParams = this.generateTransformationParameters(template);
    const shapeType = this.randomFromArray(template.parameterRanges.shapes);
    
    // Create initial shape with random starting position (not origin)
    // Keep positions reasonable and grounded (not floating randomly)
    const initialShape: Shape = {
      type: shapeType,
      position: { 
        x: this.randomInRange(-3, 3), 
        y: 0, // Keep at ground level
        z: this.randomInRange(-3, 3) 
      },
      rotation: { 
        x: 0, // No initial rotation for clarity
        y: this.randomInRange(0, 360), // Allow Y-axis rotation only
        z: 0
      },
      scale: { 
        x: 1, // Start with uniform scale
        y: 1, 
        z: 1 
      },
      color: this.getRandomColor()
    };

    // Calculate target shape and transformation matrix
    const { targetShape, transformationMatrix, compositeMatrix } = this.applyTransformation(initialShape, transformationParams);
    
    const questionText = this.generateQuestionText(template, transformationParams, shapeType, initialShape);

    // Calculate difficulty score
    const difficultyBreakdown = calculateDifficulty(transformationParams);

    return {
      id: questionId,
      templateId,
      seed: seed || Date.now(),
      questionText,
      initialShape,
      targetShape,
      transformationParameters: transformationParams,
      referenceSolution: {
        matrix: this.threeMatrixToMatrix4x4(compositeMatrix),
        finalPosition: targetShape.position
      },
      difficulty: template.difficulty,
      pointsTotal: template.gradingCriteria.pointsTotal,
      generatedAt: new Date(),
      difficultyScore: difficultyBreakdown.weightedScore,
      difficultyBreakdown: {
        aspects: difficultyBreakdown.aspects,
        totalScore: difficultyBreakdown.totalScore,
        weightedScore: difficultyBreakdown.weightedScore
      }
    };
  }

  private generateTransformationParameters(template: QuestionTemplate): TransformationParameters {
    const params: TransformationParameters = {};

    if (template.parameterRanges.translation) {
      const t = template.parameterRanges.translation;
      params.translation = {
        x: this.randomInRange(t.x[0], t.x[1]),
        y: this.randomInRange(t.y[0], t.y[1]),
        z: this.randomInRange(t.z[0], t.z[1])
      };
    }

    if (template.parameterRanges.rotation) {
      const r = template.parameterRanges.rotation;
      params.rotation = {
        axis: this.randomFromArray(r.axes),
        angle: this.randomInRange(r.angle[0], r.angle[1])
      };
    }

    if (template.parameterRanges.scaling) {
      const s = template.parameterRanges.scaling;
      params.scaling = {
        x: this.randomInRange(s.x[0], s.x[1]),
        y: this.randomInRange(s.y[0], s.y[1]),
        z: this.randomInRange(s.z[0], s.z[1])
      };
    }

    return params;
  }

  private applyTransformation(shape: Shape, params: TransformationParameters): { 
    targetShape: Shape, 
    transformationMatrix: Matrix4,
    compositeMatrix: Matrix4 
  } {
    // Create transformation matrix
    const transformMatrix = new Matrix4();
    
    // Apply transformations in order: Scale -> Rotate -> Translate
    if (params.scaling) {
      transformMatrix.makeScale(params.scaling.x, params.scaling.y, params.scaling.z);
    }

    if (params.rotation) {
      const rotationMatrix = new Matrix4();
      const axis = new ThreeVector3(params.rotation.axis.x, params.rotation.axis.y, params.rotation.axis.z);
      rotationMatrix.makeRotationAxis(axis.normalize(), (params.rotation.angle * Math.PI) / 180);
      transformMatrix.premultiply(rotationMatrix);
    }

    if (params.translation) {
      const translationMatrix = new Matrix4();
      translationMatrix.makeTranslation(params.translation.x, params.translation.y, params.translation.z);
      transformMatrix.premultiply(translationMatrix);
    }

    // Create initial position matrix (to transform from shape's current position)
    const initialMatrix = new Matrix4();
    initialMatrix.makeTranslation(shape.position.x, shape.position.y, shape.position.z);
    
    // Create initial scale matrix
    const scaleMatrix = new Matrix4();
    scaleMatrix.makeScale(shape.scale.x, shape.scale.y, shape.scale.z);
    
    // Create initial rotation matrix
    const rotMatrix = new Matrix4();
    rotMatrix.makeRotationFromEuler({
      x: (shape.rotation.x * Math.PI) / 180,
      y: (shape.rotation.y * Math.PI) / 180,
      z: (shape.rotation.z * Math.PI) / 180,
      order: 'XYZ'
    } as any);

    // Composite matrix: Initial transformations then new transformations
    const compositeMatrix = new Matrix4();
    compositeMatrix.multiplyMatrices(transformMatrix, initialMatrix);

    // Apply transformation to shape position
    const position = new ThreeVector3(shape.position.x, shape.position.y, shape.position.z);
    position.applyMatrix4(transformMatrix);

    const targetShape: Shape = {
      ...shape,
      position: { x: position.x, y: position.y, z: position.z },
      scale: params.scaling ? {
        x: shape.scale.x * params.scaling.x,
        y: shape.scale.y * params.scaling.y,
        z: shape.scale.z * params.scaling.z
      } : shape.scale
    };

    return { targetShape, transformationMatrix: transformMatrix, compositeMatrix };
  }

  private generateQuestionText(template: QuestionTemplate, params: TransformationParameters, shapeType: string, initialShape: Shape): string {
    let text = `**${template.name}** (${template.difficulty} - ${template.gradingCriteria.pointsTotal} points)\n\n`;
    
    const pos = initialShape.position;
    const rot = initialShape.rotation;
    const scale = initialShape.scale;
    
    text += `Given a ${shapeType} positioned on the ground with the following initial state:\n`;
    text += `- Position: (${pos.x.toFixed(2)}, ${pos.y.toFixed(2)}, ${pos.z.toFixed(2)})\n`;
    
    // Only show rotation if it's not default
    if (rot.y !== 0) {
      text += `- Rotation: ${rot.y.toFixed(1)}° around Y-axis\n`;
    }
    text += `- Scale: uniform (${scale.x.toFixed(2)})\n\n`;

    const transformations: string[] = [];

    if (params.translation) {
      const t = params.translation;
      transformations.push(`translate by vector (${t.x.toFixed(2)}, ${t.y.toFixed(2)}, ${t.z.toFixed(2)})`);
    }

    if (params.rotation) {
      const r = params.rotation;
      const axisName = this.getAxisName(r.axis);
      transformations.push(`rotate ${r.angle.toFixed(1)}° around the ${axisName}`);
    }

    if (params.scaling) {
      const s = params.scaling;
      if (s.x === s.y && s.y === s.z) {
        transformations.push(`scale uniformly by factor ${s.x.toFixed(2)}`);
      } else {
        transformations.push(`scale by factors (${s.x.toFixed(2)}, ${s.y.toFixed(2)}, ${s.z.toFixed(2)})`);
      }
    }

    if (transformations.length > 0) {
      text += `Apply the following transformations in order: ${transformations.join(', then ')}.\n\n`;
    }
    
    text += 'Calculate:\n';
    text += '1. The composite transformation matrix that transforms the object from its initial state to the final state\n';
    text += '2. The final position of the object\'s center after all transformations\n\n';
    text += '*Show your work including the individual transformation matrices and round final answers to 2 decimal places.*';

    return text;
  }

  private getAxisName(axis: Vector3): string {
    if (axis.x === 1 && axis.y === 0 && axis.z === 0) return 'X-axis';
    if (axis.x === 0 && axis.y === 1 && axis.z === 0) return 'Y-axis';
    if (axis.x === 0 && axis.y === 0 && axis.z === 1) return 'Z-axis';
    return `axis (${axis.x}, ${axis.y}, ${axis.z})`;
  }

  private getRandomColor(): string {
    const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];
    return this.randomFromArray(colors);
  }

  private threeMatrixToMatrix4x4(matrix: Matrix4): Matrix4x4 {
    return {
      elements: [...matrix.elements]
    };
  }
}