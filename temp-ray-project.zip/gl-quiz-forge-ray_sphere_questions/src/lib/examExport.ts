// JSON export functionality for exam questions with difficulty metadata

import { QuestionInstance } from '@/types/question';
import { DifficultyBreakdown } from './difficulty';

export interface ExamQuestionExport {
  question_id: string;
  parameters: {
    rotation_angle?: number;
    rotation_axis?: string;
    translation?: [number, number, number];
    scaling?: [number, number, number];
  };
  difficulty_score: number;
  difficulty_breakdown: {
    aspects: Array<{
      name: string;
      level: number;
      weight: number;
      description: string;
    }>;
    weighted_score: number;
  };
  initial_state: {
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
    shape: string;
  };
  target_state: {
    position: [number, number, number];
  };
  solution: {
    transformation_matrix: number[];
    final_position: [number, number, number];
  };
  question_text: string;
  generated_at: string;
}

/**
 * Export question instance to standardized JSON format
 */
export function exportQuestionToJSON(
  question: QuestionInstance,
  difficulty: DifficultyBreakdown
): ExamQuestionExport {
  const params = question.transformationParameters;
  
  return {
    question_id: question.id,
    parameters: {
      rotation_angle: params.rotation?.angle,
      rotation_axis: params.rotation ? 
        `(${params.rotation.axis.x}, ${params.rotation.axis.y}, ${params.rotation.axis.z})` : 
        undefined,
      translation: params.translation ? 
        [params.translation.x, params.translation.y, params.translation.z] : 
        undefined,
      scaling: params.scaling ? 
        [params.scaling.x, params.scaling.y, params.scaling.z] : 
        undefined,
    },
    difficulty_score: Math.round(difficulty.weightedScore * 100) / 100,
    difficulty_breakdown: {
      aspects: difficulty.aspects.map(aspect => ({
        name: aspect.name,
        level: aspect.level,
        weight: aspect.weight,
        description: aspect.description
      })),
      weighted_score: Math.round(difficulty.weightedScore * 100) / 100
    },
    initial_state: {
      position: [question.initialShape.position.x, question.initialShape.position.y, question.initialShape.position.z],
      rotation: [question.initialShape.rotation.x, question.initialShape.rotation.y, question.initialShape.rotation.z],
      scale: [question.initialShape.scale.x, question.initialShape.scale.y, question.initialShape.scale.z],
      shape: question.initialShape.type
    },
    target_state: {
      position: [question.targetShape.position.x, question.targetShape.position.y, question.targetShape.position.z]
    },
    solution: {
      transformation_matrix: question.referenceSolution.matrix.elements,
      final_position: [
        question.referenceSolution.finalPosition.x,
        question.referenceSolution.finalPosition.y,
        question.referenceSolution.finalPosition.z
      ]
    },
    question_text: question.questionText,
    generated_at: question.generatedAt.toISOString()
  };
}

/**
 * Export multiple question versions to JSON
 */
export function exportMultipleVersions(
  questions: QuestionInstance[],
  difficulties: DifficultyBreakdown[]
): string {
  const exports = questions.map((q, i) => exportQuestionToJSON(q, difficulties[i]));
  
  return JSON.stringify({
    exam_versions: exports,
    metadata: {
      version_count: questions.length,
      average_difficulty: exports.reduce((sum, e) => sum + e.difficulty_score, 0) / exports.length,
      difficulty_range: {
        min: Math.min(...exports.map(e => e.difficulty_score)),
        max: Math.max(...exports.map(e => e.difficulty_score))
      },
      generated_at: new Date().toISOString()
    }
  }, null, 2);
}

/**
 * Download JSON export as file
 */
export function downloadJSON(jsonString: string, filename: string = 'exam_questions.json') {
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
