// Difficulty scoring system for exam question fairness

import { TransformationParameters, Vector3 } from '@/types/question';

export interface DifficultyAspect {
  name: string;
  score: number;
  weight: number;
  level: 1 | 2 | 3;
  description: string;
}

export interface DifficultyBreakdown {
  aspects: DifficultyAspect[];
  totalScore: number;
  weightedScore: number;
}

/**
 * Calculate difficulty level for rotation based on angle
 * Level 1: Very common, easy angles (0°, 90°, 180°, 270°, 360°)
 * Level 2: Common but moderate angles (45°, 60°, 120°, 135°)
 * Level 3: Uncommon angles requiring more calculation (22°, 37°, 73°, etc.)
 */
export function calculateRotationDifficulty(angle: number, axis: Vector3): DifficultyAspect {
  // Normalize angle to 0-360 range
  const normalizedAngle = Math.abs(angle) % 360;
  
  let level: 1 | 2 | 3;
  let description: string;
  
  // Check for very easy angles (multiples of 90)
  if ([0, 90, 180, 270, 360].some(a => Math.abs(normalizedAngle - a) < 1)) {
    level = 1;
    description = `Easy angle (${normalizedAngle.toFixed(0)}°)`;
  }
  // Check for moderate angles (45, 60, 120, 135)
  else if ([30, 45, 60, 120, 135, 150, 210, 225, 240, 300, 315, 330].some(a => Math.abs(normalizedAngle - a) < 1)) {
    level = 2;
    description = `Moderate angle (${normalizedAngle.toFixed(0)}°)`;
  }
  // All other angles are hard
  else {
    level = 3;
    description = `Complex angle (${normalizedAngle.toFixed(0)}°)`;
  }
  
  // Check if rotation is around a standard axis or arbitrary axis
  const isStandardAxis = (axis.x === 1 && axis.y === 0 && axis.z === 0) ||
                         (axis.x === 0 && axis.y === 1 && axis.z === 0) ||
                         (axis.x === 0 && axis.y === 0 && axis.z === 1);
  
  if (!isStandardAxis) {
    level = 3; // Arbitrary axis rotations are always hard
    description += ' around arbitrary axis';
  }
  
  return {
    name: 'Rotation',
    score: level,
    weight: 0.4, // 40% of total difficulty
    level,
    description
  };
}

/**
 * Calculate difficulty level for translation
 * Level 1: Single-axis translation (only x, y, or z)
 * Level 2: Two-axis translation (e.g., x and y)
 * Level 3: Three-axis diagonal translation
 */
export function calculateTranslationDifficulty(translation: Vector3): DifficultyAspect {
  const nonZeroAxes = [
    Math.abs(translation.x) > 0.01,
    Math.abs(translation.y) > 0.01,
    Math.abs(translation.z) > 0.01
  ].filter(Boolean).length;
  
  let level: 1 | 2 | 3;
  let description: string;
  
  switch (nonZeroAxes) {
    case 1:
      level = 1;
      description = 'Single-axis translation';
      break;
    case 2:
      level = 2;
      description = 'Two-axis translation';
      break;
    case 3:
    default:
      level = 3;
      description = 'Three-axis diagonal translation';
      break;
  }
  
  // Check for decimal complexity
  const hasComplexDecimals = [translation.x, translation.y, translation.z].some(
    v => Math.abs(v) > 0 && Math.abs(v % 1) > 0.01 && Math.abs(v % 1) < 0.99
  );
  
  if (hasComplexDecimals && level < 3) {
    level = Math.min(level + 1, 3) as 1 | 2 | 3;
    description += ' with decimal values';
  }
  
  return {
    name: 'Translation',
    score: level,
    weight: 0.3, // 30% of total difficulty
    level,
    description
  };
}

/**
 * Calculate difficulty level for scaling
 * Level 1: Uniform scaling (all axes same)
 * Level 2: Two-axis non-uniform scaling
 * Level 3: Three-axis non-uniform scaling
 */
export function calculateScalingDifficulty(scaling: Vector3): DifficultyAspect {
  const epsilon = 0.01;
  const isUniform = Math.abs(scaling.x - scaling.y) < epsilon && 
                    Math.abs(scaling.y - scaling.z) < epsilon;
  
  let level: 1 | 2 | 3;
  let description: string;
  
  if (isUniform) {
    level = 1;
    description = `Uniform scaling (${scaling.x.toFixed(2)})`;
  } else {
    // Check how many axes differ
    const uniqueValues = new Set([
      Math.round(scaling.x * 100),
      Math.round(scaling.y * 100),
      Math.round(scaling.z * 100)
    ]);
    
    if (uniqueValues.size === 2) {
      level = 2;
      description = 'Two-axis non-uniform scaling';
    } else {
      level = 3;
      description = 'Three-axis non-uniform scaling';
    }
  }
  
  return {
    name: 'Scaling',
    score: level,
    weight: 0.3, // 30% of total difficulty
    level,
    description
  };
}

/**
 * Calculate overall difficulty score for a transformation question
 */
export function calculateDifficulty(params: TransformationParameters): DifficultyBreakdown {
  const aspects: DifficultyAspect[] = [];
  
  if (params.rotation) {
    aspects.push(calculateRotationDifficulty(params.rotation.angle, params.rotation.axis));
  }
  
  if (params.translation) {
    aspects.push(calculateTranslationDifficulty(params.translation));
  }
  
  if (params.scaling) {
    aspects.push(calculateScalingDifficulty(params.scaling));
  }
  
  // Calculate weighted score
  const totalScore = aspects.reduce((sum, aspect) => sum + aspect.score, 0);
  const weightedScore = aspects.reduce((sum, aspect) => sum + (aspect.score * aspect.weight), 0);
  
  return {
    aspects,
    totalScore,
    weightedScore
  };
}

/**
 * Generate balanced question versions with similar difficulty
 * Returns parameters that have difficulty scores within tolerance
 */
export function generateBalancedVersions(
  targetDifficulty: number,
  tolerance: number = 0.2,
  count: number = 3
): TransformationParameters[] {
  const versions: TransformationParameters[] = [];
  const maxAttempts = 1000;
  
  for (let i = 0; i < count && versions.length < count; i++) {
    let attempts = 0;
    let found = false;
    
    while (!found && attempts < maxAttempts) {
      const params = generateRandomTransformationParams();
      const difficulty = calculateDifficulty(params);
      
      // Check if difficulty is within tolerance
      if (Math.abs(difficulty.weightedScore - targetDifficulty) <= tolerance) {
        versions.push(params);
        found = true;
      }
      
      attempts++;
    }
  }
  
  return versions;
}

/**
 * Generate random transformation parameters
 * Helper function for balanced version generation
 */
function generateRandomTransformationParams(): TransformationParameters {
  const includeTranslation = Math.random() > 0.2;
  const includeRotation = Math.random() > 0.2;
  const includeScaling = Math.random() > 0.2;
  
  const params: TransformationParameters = {};
  
  if (includeTranslation) {
    params.translation = {
      x: Math.random() > 0.5 ? Math.random() * 10 - 5 : 0,
      y: Math.random() > 0.5 ? Math.random() * 10 - 5 : 0,
      z: Math.random() > 0.5 ? Math.random() * 10 - 5 : 0
    };
  }
  
  if (includeRotation) {
    const standardAxes = [
      { x: 1, y: 0, z: 0 },
      { x: 0, y: 1, z: 0 },
      { x: 0, y: 0, z: 1 }
    ];
    
    const angles = [0, 22, 30, 37, 45, 60, 73, 90, 120, 135, 150, 180, 210, 270];
    
    params.rotation = {
      axis: standardAxes[Math.floor(Math.random() * standardAxes.length)],
      angle: angles[Math.floor(Math.random() * angles.length)]
    };
  }
  
  if (includeScaling) {
    const uniformScale = Math.random() > 0.5;
    const scale = Math.random() * 1.5 + 0.5;
    
    params.scaling = uniformScale
      ? { x: scale, y: scale, z: scale }
      : {
          x: Math.random() * 1.5 + 0.5,
          y: Math.random() * 1.5 + 0.5,
          z: Math.random() * 1.5 + 0.5
        };
  }
  
  return params;
}

/**
 * PLACEHOLDER: Future AI Integration
 * 
 * This function will be used to paraphrase question text using AI
 * while maintaining mathematical accuracy
 */
export async function paraphraseQuestionText(originalText: string): Promise<string> {
  // TODO: Integrate with AI service (e.g., OpenAI, Claude)
  // - Extract mathematical values and preserve them
  // - Rephrase surrounding text for variety
  // - Validate that mathematical meaning is preserved
  console.log('[AI Integration Placeholder] Paraphrase question text');
  return originalText;
}

/**
 * PLACEHOLDER: Future AI Integration
 * 
 * This function will be used to generate varied OpenGL rendering code
 * that produces visually different but mathematically equivalent results
 */
export async function generateVariedRendering(baseCode: string): Promise<string> {
  // TODO: Integrate with AI service
  // - Modify lighting, camera angles, colors
  // - Keep transformation mathematics identical
  // - Generate multiple visual variations
  console.log('[AI Integration Placeholder] Generate varied rendering');
  return baseCode;
}
