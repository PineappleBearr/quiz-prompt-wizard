﻿// src/App.tsx
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

// ✅ 新增：导入 RaySphereDemo
import RaySphereDemo from "./pages/RaySphereDemo";

const queryClient = new QueryClient();

const App = () => (
    <QueryClientProvider client={queryClient}>
        <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
                <Routes>
                    {/* 首页 */}
                    <Route path="/" element={<Index />} />

                    {/* ✅ 新增路由：Ray–Sphere 演示页（必须放在 * 前面） */}
                    <Route path="/ray-sphere" element={<RaySphereDemo />} />

                    {/* 兜底 404 */}
                    <Route path="*" element={<NotFound />} />
                </Routes>
            </BrowserRouter>
        </TooltipProvider>
    </QueryClientProvider>
);
export default App;

